//
//  MASLoggingConfiguration.h
//  MASFoundation
//
//  Copyright © 2022 CA Technologies. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import <MASFoundation/MASObject.h>
#import <MASFoundation/MASLoggerConfiguration.h>



@interface MASLoggingConfiguration : MASObject <MASLoggerConfiguration>



- (instancetype _Nonnull)initWithLogSeverity:(MASLogSeverity)minimumLogSeverity;



- (instancetype _Nonnull)initWithLogSeverity:(MASLogSeverity)minimumLogSeverity
                             shouldLogToFile:(BOOL)enableFileLogging
                          daysToKeepLogFiles:(NSUInteger)daysToKeepLogFiles;

@end

