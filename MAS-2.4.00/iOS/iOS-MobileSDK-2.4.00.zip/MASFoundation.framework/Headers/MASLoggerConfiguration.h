//
//  MASLoggerConfiguration.h
//  MASFoundation
//
//  Copyright © 2022 CA Technologies. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import <MASFoundation/MASConstants.h>



@protocol MASLoggerConfiguration <NSObject>



/**
 *  minimumLogSeverity: The minimum supported `MASLogSeverity`.
 *  Any log message having a `severity` less than `minimumLogSeverity` will be silently
 *  ignored by the configuration.
 */
@property(assign)MASLogSeverity minimumLogSeverity;



/**
 *  isRedactionEnabled: If YES, we should redact sensitive data
 */
@property(assign)BOOL isRedactionEnabled;



/**
 *  enableFileLogging: Used to indicate whether log messages be recorded in a log file.
 */
@property(assign)BOOL enableFileLogging;



/**
 *  daysToKeepLogFiles: The number of days for which log files should be retained.
 */
@property(assign)NSUInteger daysToKeepLogFiles;

@end
