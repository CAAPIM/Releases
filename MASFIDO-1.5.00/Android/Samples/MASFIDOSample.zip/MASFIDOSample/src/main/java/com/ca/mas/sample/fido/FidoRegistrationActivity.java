package com.ca.mas.sample.fido;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.ca.mas.fido.MASFido;
import com.ca.mas.fido.exception.MASFidoException;
import com.ca.mas.foundation.MASCallback;

import org.json.JSONObject;

public class FidoRegistrationActivity extends AppCompatActivity {

    private ProgressDialog mProgressDialog;
    EditText etUsername;
    Button btnRegister;
    TextView tvResult;
    Activity context;
    String mBaseUri;
    String mRpIdPath;
    String mRequestPath;
    String mResponsePath;
    private static final int REGISTRATION_REQUEST_CODE = 1001;
    private static final String TAG = "FidoRegA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fido_registration);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setCancelable(true);
        context = this;
        Intent intent = getIntent();
        mBaseUri = intent.getStringExtra("mBaseUri");
        mRpIdPath = intent.getStringExtra("mRpIdPath");
        mRequestPath = intent.getStringExtra("mRequestPath");
        mResponsePath = intent.getStringExtra("mResponsePath");
        populateView();
    }

    private void populateView() {
        etUsername = (EditText)findViewById(R.id.etusername);
        btnRegister = (Button)findViewById(R.id.btnfidoregister);
        tvResult = (TextView)findViewById(R.id.tvResult);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    MASFido.registerWithFido(etUsername.getText().toString(), new MASCallback<JSONObject>() {
                        @Override
                        public void onSuccess(JSONObject result) {
                            tvResult.setText(result.toString());
                            Toast.makeText(FidoRegistrationActivity.this, result.toString(), Toast.LENGTH_SHORT).show();
                            Log.i("success", "success");
                        }
                        @Override
                        public void onError(Throwable e) {
                            tvResult.setText(e.getMessage());
                            Toast.makeText(FidoRegistrationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.i("error", e.getMessage());

                        }
                    });
                } catch (MASFidoException e) {
                    tvResult.setText(e.getErrorDetails().toString());
                    Toast.makeText(FidoRegistrationActivity.this, e.getErrorDetails().toString(), Toast.LENGTH_SHORT).show();
                    Log.i("error", e.getErrorDetails().toString());
                }
                /*String mUserName = etUsername.getText().toString();
                int permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE);

                if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(context, new String[]{Manifest.permission.READ_PHONE_STATE}, 12123);
                    return;
                } else {
                }

                Intent intent = new Intent(context, RegistrationSelectActivity.class);
                intent.putExtra(CommonPreferences.REQUEST_URI, mBaseUri + mRpIdPath + mRequestPath);
                intent.putExtra(CommonPreferences.RESPONSE_URI, mBaseUri + mRpIdPath + mResponsePath);
                intent.putExtra(CommonPreferences.USER_NAME, mUserName );
                startActivityForResult(intent, REGISTRATION_REQUEST_CODE);
                return;*/
            }
        });
    }
/*

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REGISTRATION_REQUEST_CODE) {
            mProgressDialog.dismiss();
            if(data != null) {
                showResult(data.getStringExtra(CommonPreferences.RESPONSE_MESSAGE));
            }
            return;
        }

        if (RESULT_OK != resultCode) {
            if (CommonPreferences.sDeregister == requestCode) {
                Log.w(TAG, "Deregistration is succeeded");
                mProgressDialog.dismiss();
                return;
            }

            int errorCode = UafClient.getErrorCode(data);
            Log.w(TAG, "onActivityResult resultCode is not RESULT_OK. ErrorCode is: " + errorCode);

            mProgressDialog.dismiss();

            showResult(ErrorCode.stringValueOf((short) errorCode));
            return;
        }

        asyncExecute(requestCode, data);
    }
    private void asyncExecute(int requestCode, Intent data) {
        UafClientAsyncDataModel model = new UafClientAsyncDataModel();
        model.setContext(context);
        model.setmBaseUri(mBaseUri);
        model.setmRpIdPath(mRpIdPath);
        model.setmProgressDialog(mProgressDialog);
        model.setmRequestPath(mRequestPath);
        model.setmResponsePath(mResponsePath);
        model.setmUserName(etUsername.getText().toString());
        new UafClientAsyncTask(model).execute(CommonPreferences.sCallback, this, requestCode, data);
    }

    private void showResult(String str) {
        if(mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
        tvResult.setText(str);
    }

    @Override
    public void showFidoResult(String message) {
        if(mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
        tvResult.setText(message);
    }*/
}
