//
//  MASFIDOService.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

@import UIKit;

#import "MASFIDOProvider.h"

#import <MASFoundation/MASService.h>
#import <MASFoundation/MASConstants.h>



@interface MASFIDOService : MASService



///--------------------------------------
/// @name Properties
///--------------------------------------

# pragma mark - Properties

/**
 *  The current MASFIDOProvider
 */
@property (nonatomic, strong, readonly) MASFIDOProvider *fidoProvider;



///--------------------------------------
/// @name MASFIDOProvider
///--------------------------------------

# pragma mark - MASFIDOProvider

/**
*  Register a user via FIDO UAF request with user's Biometric credentials.
*
*  @param userName The userName of the user.
*  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
*      receive the JSON response object or an NSError object if there is a failure.
*/
- (void)registerWithUserName:(NSString *)userName
                  completion:(MASResponseInfoErrorBlock)completion;



/**
 *  Authenticate a user via FIDO UAF request with pre-registered Biometric credentials.
 *
 *  This will create an [MAUser currentUser] upon a successful result.
 *
 *  @param userName The userName of the user.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.  On a successful
 *   completion, the user
 *  available via [MASUser currentUser] has been updated with the new information.
 */
- (void)authenticateWithUserName:(NSString *)userName
                      completion:(MASResponseInfoErrorBlock)completion;



/**
 *  Confirm a critical transaction via FIDO UAF request with pre-registered Biometric credentials.
 *
 *  This will create an [MAUser currentUser] upon a successful result.
 *
 *  @param userName The userName of the user.
 *  @param message The message about the critical transaction that needs the confirmation of the user.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.  On a successful 
 *   completion, the user
 *  available via [MASUser currentUser] has been updated with the new information.
 */
- (void)confirmTransactionWithMessage:(NSString *)message
                             userName:(NSString *)userName
                           completion:(MASResponseInfoErrorBlock)completion;



/**
 *  De-Register a user via FIDO UAF request with all of the pre-registered Biometric credentials.
 *
 *  @param userName The userName of the user.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.  On a successful completion, the
 *  user's
 *  Biometric credentials are de-registered.
 */
- (void)deregisterWithUserName:(NSString *)userName
                    completion:(MASResponseInfoErrorBlock)completion;


/**
 *  De-Register a user via FIDO UAF request with selected pre-registered Biometric credentials.
 *
 *  @param userName The userName of the user.
 *  @param AAIDArray The array of AAIDs to be deleted.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.  On a successful completion, the
 *  user's selected
 *  Biometric credentials are de-registered.
 */
- (void)deregisterAAIDsForUserName:(NSString *)userName
                    completion:(MASResponseInfoErrorBlock)completion;



/**
 *  SDK callback to this method with post request processing secure client data.
 *
 *  @param url NSURL to be handled.
 */
- (BOOL)validateURLForPostRequestProcessingURL:(NSURL *)url;



/**
 *  FIDO Error
 *  
 *  @param errorCode The MASFIDOError code.
 *  @param errorDomain One of the MASFIDOErrorDomain.
 */
- (NSError *)errorForFIDOErrorCode:(MASFIDOError)errorCode errorDomain:(NSString *)errorDomain;


@end
