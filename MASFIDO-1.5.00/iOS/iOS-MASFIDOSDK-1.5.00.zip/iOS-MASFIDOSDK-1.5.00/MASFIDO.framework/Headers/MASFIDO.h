//
//  MASFIDO.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import <UIKit/UIKit.h>

//! Project version number for MASFIDO.
FOUNDATION_EXPORT double MASFIDOVersionNumber;

//! Project version string for MASFIDO.
FOUNDATION_EXPORT const unsigned char MASFIDOVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MASFIDO/PublicHeader.h>

//
// Top Level
//
#import "MASFIDOConstants.h"

//
// Models
//
#import "MASAuthCredentialsFIDO.h"
#import "MASFIDORequestProcessingResponse.h"

//
// Categories
//
#import "MAS+FIDO.h"
#import "MASUser+FIDO.h"
