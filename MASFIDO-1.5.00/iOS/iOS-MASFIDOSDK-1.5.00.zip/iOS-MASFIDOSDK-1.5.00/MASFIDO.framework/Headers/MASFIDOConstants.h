//
//  MASFIDOConstants.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//


///--------------------------------------
/// @name MASFIDOProvider Type
///--------------------------------------

/**
 * The enumerated MASFIDOProviderType types.
 *
 */
typedef NS_ENUM(NSInteger, MASFIDOProviderType)
{
    MASFIDOProviderTypeUnknown = -1,
    
    // MASFIDOProviderType Nexsign SDS
    MASFIDOProviderTypeSDS,
    
    // MASFIDOProviderType NNL
    MASFIDOProviderTypeNNL
};


///--------------------------------------
/// @name MASFIDO Errors
///--------------------------------------

# pragma mark - MASFIDO Errors

/**
 * The NSString error domain used by all MAS server related FIDO level NSErrors.
 */
static NSString *const _Nonnull MASFIDOErrorDomain = @"com.ca.MASFIDO:ErrorDomain";



/**
 *  The NSString error domain used by all MASFIDO local level NSErrors.
 */
static NSString *const _Nonnull MASFIDOErrorDomainLocal = @"com.ca.MASFIDO.localError:ErrorDomain";



/**
 *  The NSString error domain used by all target API level NSErrors.
 */
static NSString *const _Nonnull MASFIDOErrorDomainFIDOProvider = @"com.ca.MASFIDO.fidoProvider:ErrorDomain";



/**
 * The enumerated error codes for FIDO level NSErrors.
 */
typedef NS_ENUM (NSInteger, MASFIDOError)
{
    MASFIDOErrorCodeUnknown = -1,
    
    //
    // FIDO UAF Error codes
    //
    MASFIDOErrorCodeOKOperationCompleted = 911100,
    MASFIDOErrorCodeMessageAccepted = 911101,
    MASFIDOErrorCodeBadRequest = 911102,
    MASFIDOErrorCodeUnauthorized = 911103,
    MASFIDOErrorCodeForbidden = 911104,
    MASFIDOErrorCodeUserNotFound = 911105,
    MASFIDOErrorCodeRequestTimedout = 911106,
    MASFIDOErrorCodeUnknownAAID = 911107,
    MASFIDOErrorCodeUnknownKeyID = 911108,
    MASFIDOErrorCodeChannelBindingRefused = 911109,
    MASFIDOErrorCodeInvalidRequest = 911110,
    MASFIDOErrorCodeUnacceptableAuthenticator = 911111,
    MASFIDOErrorCodeRevokedAuthenticator = 911112,
    MASFIDOErrorCodeUnacceptableAlgorithm = 911113,
    MASFIDOErrorCodeUnacceptableAttestation = 911114,
    MASFIDOErrorCodeUnacceptableClientCapabilities = 911115,
    MASFIDOErrorCodeUnacceptableContent = 911116,
    MASFIDOErrorCodeInternalServerError = 911117,
    MASFIDOErrorCodeRelyingPartyServerError = 911118,
    MASFIDOErrorCodeFIDOServerConnectivityError = 911119,
    
    
    //
    // FIDO UAF Status codes
    //
    MASFIDOErrorCodeOperationSuccessfull = 922100,
    MASFIDOErrorCodeOperationInProgress = 922101,
    MASFIDOErrorCodeOperationInsecure = 922102,
    MASFIDOErrorCodeOperationCancelledByUser = 922103,
    MASFIDOErrorCodeOperationUnsupportedUAFVersion = 922104,
    MASFIDOErrorCodeOperationNoSuitableAuthenticatorsFound = 922105,
    MASFIDOErrorCodeUAFProtocolError = 922106,
    MASFIDOErrorCodeUntrustedFacetIdFound = 922107,
    MASFIDOErrorCodeUnknownError = 922255,
    
    
    //
    // MASFIDO Validation
    //
    MASFIDOErrorCodeLocalOperationFailure = 922131,
    MASFIDOErrorCodeServerNotReachable = 922132,
    MASFIDOErrorCodeAlreadyRegistered = 922133,
    MASFIDOErrorCodeNoSupportedAuthenticatorsFound = 922134,
    MASFIDOErrorCodeDeviceIDNotResolved = 922135,
    MASFIDOErrorCodeInvalidServerResponse = 922136,
    MASFIDOErrorCodeAuthenticatorDiscoveryFailure = 922137,
    MASFIDOErrorCodeNoSupportForBiometricsOnDevice = 922138,
    MASFIDOErrorCodeInvalidInputParam = 922139,
    MASFIDOErrorCodeRequestCancelled = 922140,
    MASFIDOErrorCodeInitializationFailed = 922141,
    MASFIDOErrorCodeNoFIDOProviderInConfiguration = 922142,
    MASFIDOErrorCodeClassNotFound = 922143,
    MASFIDOErrorCodeProcessRequestFailed = 922144,
    MASFIDOErrorCodeUserCancelledRegistration = 922145,
    MASFIDOErrorCodeObjectNotSupported = 922146,
    MASFIDOErrorCodeParameterCanNotBeEmptyOrNil = 922147,
    MASFIDOErrorCodeInvalidGatewayCustomFIDOConfiguration = 922148,
    MASFIDOErrorCodeBiometricPolicyNotEnabled = 922149,
    MASFIDOErrorCodeNoAuthenticatorsRegistered = 922150,
};
