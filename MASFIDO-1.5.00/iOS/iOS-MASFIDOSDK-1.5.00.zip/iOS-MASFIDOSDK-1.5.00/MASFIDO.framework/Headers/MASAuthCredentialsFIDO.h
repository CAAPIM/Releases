//
//  MASAuthCredentialsFIDO.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import <MASFoundation/MASFoundation.h>

#import <MASFoundation/MASAuthCredentials.h>



@interface MASAuthCredentialsFIDO : MASAuthCredentials

///--------------------------------------
/// @name Properties
///--------------------------------------

# pragma mark - Properties


/**
 * Credential, userName.
 */
@property (nonatomic, copy, readonly, nullable) NSString *userName;



/**
 Designated factory method to construct MASAuthCredentials object for FIDO credentials
 
 @param userName NSString of userName for credentials
 @return MASAuthCredentialsFIDO object that can be used as auth credentials to register or login
 */
+ (MASAuthCredentialsFIDO * _Nullable)initWithUserName:(NSString * _Nonnull)userName;



@end
