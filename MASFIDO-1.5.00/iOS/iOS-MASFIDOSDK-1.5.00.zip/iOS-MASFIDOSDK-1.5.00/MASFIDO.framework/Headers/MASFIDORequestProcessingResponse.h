//
//  MASFIDORequestProcessingResponse.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import <Foundation/Foundation.h>



@interface MASFIDORequestProcessingResponse : NSObject



///--------------------------------------
/// @name Lifecycle
///--------------------------------------

# pragma mark - Lifecycle

/**
 * Retrieve the shared MASAuthorizationResponse singleton.
 *
 * Note, subclasses should override this version of the method.
 *
 * @return Returns the shared MASAuthorizationResponse singleton.
 */
+ (instancetype _Nullable)sharedInstance;



NS_ASSUME_NONNULL_BEGIN

#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_9_3

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options;
#endif



- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

NS_ASSUME_NONNULL_END



@end
