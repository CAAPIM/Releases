//
//  MAS+FIDO.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import <Foundation/Foundation.h>

#import "MASFIDOConstants.h"


@interface MAS (FIDO)



/**
 Return the currently configured FIDO Provider for MASFIDO
 
 @return MASFIDOProviderType configured for MASFIDO
 */
+ (MASFIDOProviderType)MASFIDOProviderType;



@end
