//
//  AppDelegate.h
//  MASFIDOSample
//
//  Created by YUSSY01 on 29/03/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

