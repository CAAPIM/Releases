//
//  ResultsViewController.h
//  MASFIDOSample
//
//  Created by YUSSY01 on 09/05/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ResultsViewController : UITableViewController



@property (nonatomic, assign)BOOL otpProtected;



@property (nonatomic, strong)NSArray *productList;



@end
