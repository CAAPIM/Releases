//
//  LoginViewController.m
//  MASFIDOSample
//
//  Created by YUSSY01 on 12/06/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import "LoginViewController.h"

#import <MASFoundation/MASUser.h>
#import <MASFIDO/MASUser+FIDO.h>

#import <MASFoundation/MASAuthCredentialsPassword.h>
#import <MASFIDO/MASAuthCredentialsFIDO.h>

#import <SafariServices/SafariServices.h>

#import "MASLoginQRCodeView.h"
#import "NSDictionary+JSONString.h"
#import "UIImage+MASUI.h"
#import "MASICenterFlowLayout.h"
#import "MASAuthenticationProviderCollectionViewCell.h"


@interface LoginViewController ()
    <UICollectionViewDataSource, UICollectionViewDelegate, UITextFieldDelegate,
        MASAuthorizationResponseDelegate>

# pragma mark - IBOutlets

@property (nonatomic, weak) IBOutlet UITextField *userNameField;
@property (nonatomic, weak) IBOutlet UITextField *passwordField;
@property (nonatomic, weak) IBOutlet UIButton *loginBtn;
@property (nonatomic, weak) IBOutlet UIButton *fidoLoginBtn;
@property (nonatomic, weak) IBOutlet UIButton *cancelBtn;
@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, weak) IBOutlet UIScrollView *scrollView;
@property (nonatomic, weak) IBOutlet UILabel *errorLabel;
@property (nonatomic, strong) MASProximityLoginQRCode *qrCode;


@end


@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.error) {
        
        self.errorLabel.text = [self.error localizedDescription];
    }
    
    //
    //  UITextField - bottom border only, and icon for each field
    //
    self.userNameField.borderStyle = UITextBorderStyleNone;
    self.userNameField.layer.backgroundColor = [UIColor whiteColor].CGColor;
    self.userNameField.layer.masksToBounds = NO;
    self.userNameField.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    self.userNameField.layer.shadowOffset = CGSizeMake(0.0, 1.0);
    self.userNameField.layer.shadowRadius = 0.0;
    self.userNameField.layer.shadowOpacity = 1.0;
    self.userNameField.leftViewMode = UITextFieldViewModeAlways;
    
    UIImageView *userIconImgView = [[UIImageView alloc] initWithFrame:CGRectMake(3, 0, 18, 18)];
    [userIconImgView setImage:[UIImage masUIImageNamed:@"ic_account_circle"]];
    UIView *userView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 31, 18)];
    [userView addSubview:userIconImgView];
    self.userNameField.leftView = userView;
    
    self.passwordField.borderStyle = UITextBorderStyleNone;
    self.passwordField.layer.backgroundColor = [UIColor whiteColor].CGColor;
    self.passwordField.layer.masksToBounds = NO;
    self.passwordField.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    self.passwordField.layer.shadowOffset = CGSizeMake(0.0, 1.0);
    self.passwordField.layer.shadowRadius = 0.0;
    self.passwordField.layer.shadowOpacity = 1.0;
    self.passwordField.leftViewMode = UITextFieldViewModeAlways;
    
    UIImageView *passwordIconImgView = [[UIImageView alloc] initWithFrame:CGRectMake(3, 0, 18, 18)];
    [passwordIconImgView setImage:[UIImage masUIImageNamed:@"ic_lock_outline"]];
    UIView *passView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 31, 18)];
    [passView addSubview:passwordIconImgView];
    self.passwordField.leftView = passView;
    
    //
    // CollectionView
    //
    MASICenterFlowLayout *layout = [MASICenterFlowLayout new];
    layout.minimumInteritemSpacing = 6.0f;
    layout.minimumLineSpacing = 5.0f;
    
    //
    //  Register the class and nib for custom cell
    //
    [self.collectionView setCollectionViewLayout:layout animated:NO];
    [self.collectionView registerClass:[MASAuthenticationProviderCollectionViewCell class]
            forCellWithReuseIdentifier:[MASAuthenticationProviderCollectionViewCell cellId]];
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"MASAuthenticationProviderCollectionViewCell" bundle:nil]
          forCellWithReuseIdentifier:[MASAuthenticationProviderCollectionViewCell cellId]];
    
    
    //
    //  Combine QR code and social login
    //
    if (self.proximityLoginProvider)
    {
        NSArray *combinedArray = [self.socialLoginAuthenticationProviders arrayByAddingObject:self.proximityLoginProvider];
        self.socialLoginAuthenticationProviders = combinedArray;
    }
    
    //
    //  QR Code session sharing
    //
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceiveAuthorizationCodeFromSessionSharing:)
                                                 name:MASDeviceDidReceiveAuthorizationCodeFromProximityLoginNotification
                                               object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


# pragma mark - IBActions

- (IBAction)onCancelSelected:(id)sender
{
    
    [self.activityIndicator startAnimating];
    
    __block LoginViewController *blockSelf = self;
    
    //
    // Ensure this code runs in the main UI thread
    //
    dispatch_async(dispatch_get_main_queue(), ^{
        
        //
        // Stop progress animation
        //
        [blockSelf.activityIndicator stopAnimating];
        
        //
        // Cancel the operation
        //
        [self cancel];
    });
}


- (IBAction)onLoginSelected:(id)sender
{
    [_loginBtn setEnabled:NO];
    [_cancelBtn setEnabled:NO];
    [_fidoLoginBtn setEnabled:NO];
    
    [self.activityIndicator startAnimating];
    
    //
    // Make sure the keyboard is closed
    //
    [self.userNameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
    
    __block LoginViewController *blockSelf = self;
    
    
    MASAuthCredentialsPassword *authCredentialsPassword =
        [MASAuthCredentialsPassword initWithUsername:self.userNameField.text password:self.passwordField.text];
    
    
    if (self.authCredentialsBlock) {
        
        //
        // Dsmiss the view controller
        //
        [self dismissLoginViewControllerAnimated:YES completion:^{
            
            self.authCredentialsBlock(authCredentialsPassword, NO,
                                      ^(BOOL completed, NSError * _Nullable error) {
                                          
                                          //
                                          // Ensure this code runs in the main UI thread
                                          //
                                          dispatch_async(dispatch_get_main_queue(), ^{
                                              
                                              //
                                              // Stop progress animation
                                              //
                                              [blockSelf.activityIndicator stopAnimating];
                                              
                                              //
                                              // Handle the error
                                              //
                                              if(error)
                                              {
                                                  [_loginBtn setEnabled:YES];
                                                  [_cancelBtn setEnabled:YES];
                                                  [_fidoLoginBtn setEnabled:YES];
                                                  
                                                  dispatch_async(dispatch_get_main_queue(), ^
                                                                 {
                                                                     UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Error"
                                                                                                                                              message:[error localizedDescription]
                                                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                                                     
                                                                     UIAlertAction *ok = [UIAlertAction  actionWithTitle:@"OK"
                                                                                                                   style:UIAlertActionStyleDefault
                                                                                                                 handler:^(UIAlertAction * action)
                                                                                          {
                                                                                              [alertController dismissViewControllerAnimated:YES completion:nil];
                                                                                              
                                                                                              if (self.completionBlock) {
                                                                                                  
                                                                                                  self.completionBlock(completed, error);
                                                                                              }
                                                                                              
                                                                                              return;
                                                                                          }];
                                                                     
                                                                     [alertController addAction:ok];
                                                                     
                                                                     [[UIApplication sharedApplication].keyWindow.rootViewController
                                                                      presentViewController:alertController animated:NO completion:nil];
                                                                 });
                                                  
                                                  return;
                                              }                
                                          });
                                      });
        }];
        
        return;
    }
}


- (IBAction)onFIDOLoginSelected:(id)sender
{
    [_loginBtn setEnabled:NO];
    [_cancelBtn setEnabled:NO];
    [_fidoLoginBtn setEnabled:NO];
    
    [self.activityIndicator startAnimating];
    
    //
    // Make sure the keyboard is closed
    //
    [self.userNameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
    
    
    MASAuthCredentialsFIDO *authCredentialsFIDO =
        [MASAuthCredentialsFIDO initWithUserName:self.userNameField.text];
    
    __block LoginViewController *blockSelf = self;
    
    if (self.authCredentialsBlock) {
        
        //
        // Dsmiss the view controller
        //
        [self dismissLoginViewControllerAnimated:YES completion:^{
            
            self.authCredentialsBlock(authCredentialsFIDO, NO, ^(BOOL completed, NSError * _Nullable error) {
                
                //
                // Ensure this code runs in the main UI thread
                //
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    //
                    // Stop progress animation
                    //
                    [blockSelf.activityIndicator stopAnimating];
                    
                    //
                    // Handle the error
                    //
                    if(error)
                    {
                        [_loginBtn setEnabled:YES];
                        [_cancelBtn setEnabled:YES];
                        [_fidoLoginBtn setEnabled:YES];
                        
                        dispatch_async(dispatch_get_main_queue(), ^
                                       {
                                           UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Error"
                                                                                                                    message:[[error userInfo] jsonStringWithPrettyPrint:YES]
                                                                                                             preferredStyle:UIAlertControllerStyleAlert];
                                           
                                           UIAlertAction *ok = [UIAlertAction  actionWithTitle:@"OK"
                                                                                         style:UIAlertActionStyleDefault
                                                                                       handler:^(UIAlertAction * action)
                                                                {
                                                                    [alertController dismissViewControllerAnimated:YES completion:nil];
                                                                    
                                                                    if (self.completionBlock) {
                                                                        
                                                                        self.completionBlock(completed, error);
                                                                    }
                                                                    
                                                                    return;
                                                                }];
                                           
                                           [alertController addAction:ok];
                                           
                                           [[UIApplication sharedApplication].keyWindow.rootViewController
                                            presentViewController:alertController animated:NO completion:nil];
                                       });
                        
                        return;
                    }
                });
            });
        }];
        
        return;
    }
}


# pragma mark - Private

- (void)didReceiveAuthorizationCodeFromSessionSharing:(NSNotification *)notification
{
    [_loginBtn setEnabled:NO];
    [_cancelBtn setEnabled:NO];
    [_fidoLoginBtn setEnabled:NO];
    
    __block LoginViewController *blockSelf = self;
    
    //
    // Make sure the keyboard is closed
    //
    [self.userNameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
    
    NSString *authorizationCode = [notification.object objectForKey:@"code"];
    
    //
    // Stop QR Code session sharing
    //
    [_qrCode stopDisplayingQRCodeImageForProximityLogin];
    
    //
    // Start activity indicator
    //
    [self.activityIndicator startAnimating];
    
    MASAuthCredentialsAuthorizationCode *authCredentialsAuthCode =
        [MASAuthCredentialsAuthorizationCode initWithAuthorizationCode:authorizationCode];
    
    
    if (self.authCredentialsBlock) {
        
        self.authCredentialsBlock(authCredentialsAuthCode, NO,
                                  ^(BOOL completed, NSError * _Nullable error) {
                                      
                                      //
                                      // Ensure this code runs in the main UI thread
                                      //
                                      dispatch_async(dispatch_get_main_queue(), ^{
                                          
                                          //
                                          // Stop progress animation
                                          //
                                          [blockSelf.activityIndicator stopAnimating];
                                          
                                          //
                                          // Handle the error
                                          //
                                          if(error)
                                          {
                                              [_loginBtn setEnabled:YES];
                                              [_cancelBtn setEnabled:YES];
                                              [_fidoLoginBtn setEnabled:YES];
                                              
                                              dispatch_async(dispatch_get_main_queue(), ^
                                                             {
                                                                 UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Error"
                                                                                                                                          message:[error localizedDescription]
                                                                                                                                   preferredStyle:UIAlertControllerStyleAlert];
                                                                 
                                                                 UIAlertAction *ok = [UIAlertAction  actionWithTitle:@"OK"
                                                                                                               style:UIAlertActionStyleDefault
                                                                                                             handler:^(UIAlertAction * action)
                                                                                      {
                                                                                          [alertController dismissViewControllerAnimated:YES completion:nil];
                                                                                      }];
                                                                 
                                                                 [alertController addAction:ok];
                                                                 
                                                                 [self presentViewController:alertController animated:NO completion:nil];
                                                             });
                                              
                                              return;
                                          }                
                                      });
                                  });
        
        //
        // Dsmiss the view controller
        //
        [self dismissLoginViewControllerAnimated:YES completion:nil];
        
        return;
    }
}

- (void)displayQRCodeOverlay
{
    MASLoginQRCodeView *qrCodeView = [[MASLoginQRCodeView alloc] initWithFrame:self.view.bounds];
    [qrCodeView displayQRCodeWithProvider:self.proximityLoginProvider];
    
    [UIView transitionWithView:self.view
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^ { [self.view addSubview:qrCodeView]; }
                    completion:nil];
}


# pragma mark - UICollectionViewDelegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //DLog(@"called for item at indexPath: %@", indexPath);
    
    //
    // Retrieve the authenticatin provider
    //
    MASAuthenticationProvider *provider =[self.socialLoginAuthenticationProviders objectAtIndex:indexPath.item];
    
    //
    // Check if selected provider is available
    //
    if (![[self.availableProvider lowercaseString] isEqualToString:@"all"] && ![provider.identifier isEqualToString:self.availableProvider])
    {
        //
        // If not all is available and the selected one is not the one that is available, skip
        //
        return;
    }
    
    //
    // if the authentication provider exists
    //
    if (provider && ![provider.identifier isEqualToString:@"qrcode"])
    {
        SFSafariViewController *viewController = [[SFSafariViewController alloc] initWithURL:provider.authenticationUrl];
        [[MASAuthorizationResponse sharedInstance] setDelegate:self];
        
        //
        // Show the controller
        //
        [self.navigationController presentViewController:viewController animated:YES completion:nil];
    }
    else if (provider && [provider.identifier isEqualToString:@"qrcode"])
    {
        [self displayQRCodeOverlay];
    }
}


# pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSInteger count = self.socialLoginAuthenticationProviders.count;
    
    NSLog(@"called and social login providers count: %lu with providers:\n\n%@\n\n",
         (unsigned long)count, self.socialLoginAuthenticationProviders);
    
    return count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //DLog(@"called for item at indexPath: %@", indexPath);
    
    //
    // Retreive the cell
    //
    MASAuthenticationProviderCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:[MASAuthenticationProviderCollectionViewCell cellId] forIndexPath:indexPath];
    if(!cell)
    {
        NSLog(@"\n\nWarning no collection view cell was returned\n\n");
        
        return nil;
    }
    
    //
    // Retrieve the authenticatin provider
    //
    MASAuthenticationProvider *provider =[self.socialLoginAuthenticationProviders objectAtIndex:indexPath.item];
    
    //
    // Update the cell
    //
    [cell updateCellWithAuthenticationProvider:provider availableProvider:self.availableProvider];
    cell.accessibilityIdentifier = [NSString stringWithFormat:@"masui-sociallogin-%@",provider.identifier];
    
    return cell;
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //DLog(@"called for item at indexPath: %@", indexPath);
    
    return [MASAuthenticationProviderCollectionViewCell cellSize];
}

# pragma mark - public

- (void)cancel
{
    [self dismissLoginViewControllerAnimated:YES completion:^{
        
        if (_authCredentialsBlock)
        {
            _authCredentialsBlock(nil, YES, nil);
        }
        
        if (_completionBlock) {
            
            _completionBlock(YES, nil);
        }
        
        return;
    }];
}


- (void)dismissLoginViewControllerAnimated:(BOOL)animated completion: (void (^)(void))completion
{
    [self dismissViewControllerAnimated:animated completion:completion];
}





@end
