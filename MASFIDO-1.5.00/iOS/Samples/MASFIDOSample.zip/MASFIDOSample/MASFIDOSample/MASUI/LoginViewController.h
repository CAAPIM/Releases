//
//  LoginViewController.h
//  MASFIDOSample
//
//  Created by YUSSY01 on 12/06/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


#import <MASFoundation/MASAuthenticationProvider.h>

#import <MASFoundation/MASConstants.h>


@interface LoginViewController : UIViewController


/**
 @warning DO NOT MANUALLY MODIFY THIS PROPERTY
 
 MASAuthCredentialsBlock to handle auth credential login.
 */
@property (nonatomic, copy) MASAuthCredentialsBlock authCredentialsBlock;


/**
 @warning DO NOT MANUALLY MODIFY THIS PROPERTY
 
 MASCompletionErrorBlock to notify original caller for the result of the login.
 */
@property (nonatomic, copy) MASCompletionErrorBlock completionBlock;


/**
 @warning DO NOT MANUALLY MODIFY THIS PROPERTY
 
 NSArray of MASAuthenticationProvider for social login.
 */
@property (nonatomic, strong) NSArray *socialLoginAuthenticationProviders;


/**
 @warning DO NOT MANUALLY MODIFY THIS PROPERTY
 
 NSString of currently available MASAuthenticationProvider.
 */
@property (nonatomic, strong) NSString *availableProvider;


/**
 @warning DO NOT MANUALLY MODIFY THIS PROPERTY
 
 MASAuthenticationProvider for Proximity Login.
 */
@property (nonatomic, strong) MASAuthenticationProvider *proximityLoginProvider;


@property (nonatomic, strong) NSError *error;


@end
