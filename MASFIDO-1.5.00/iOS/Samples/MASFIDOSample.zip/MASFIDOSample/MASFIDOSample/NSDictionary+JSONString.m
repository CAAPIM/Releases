//
//  NSDictionary+JSONString.m
//  MASFIDOSample
//
//  Created by YUSSY01 on 08/05/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import "NSDictionary+JSONString.h"


@implementation NSDictionary (JSONString)


-(NSString*)jsonStringWithPrettyPrint:(BOOL)prettyPrint {
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self
                                                       options:(NSJSONWritingOptions)    (prettyPrint ? NSJSONWritingPrettyPrinted : 0)
                                                         error:&error];
    
    if (! jsonData) {
        NSLog(@"bv_jsonStringWithPrettyPrint: error: %@", error.localizedDescription);
        return @"{}";
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}


@end
