//
//  ResultsViewController.m
//  MASFIDOSample
//
//  Created by YUSSY01 on 09/05/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import "ResultsViewController.h"

@interface ResultsViewController ()

@end

@implementation ResultsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
 
    self.title = @"Products";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.productList count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ProductCell" forIndexPath:indexPath];
    
    NSDictionary *productInfo = [self.productList objectAtIndex:indexPath.row];
    
    if (_otpProtected)
        cell.textLabel.text = productInfo[@"productName"];
    else
        cell.textLabel.text = productInfo[@"name"];
    
    cell.detailTextLabel.text = productInfo[@"price"];
    
    return cell;
}



@end
