//
//  MainViewController.h
//  MASFIDOSample
//
//  Created by YUSSY01 on 20/04/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UITableViewController

@end
