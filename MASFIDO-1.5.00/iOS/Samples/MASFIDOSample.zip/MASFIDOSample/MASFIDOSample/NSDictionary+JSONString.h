//
//  NSDictionary+JSONString.h
//  MASFIDOSample
//
//  Created by YUSSY01 on 08/05/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSDictionary (JSONString)


-(NSString*)jsonStringWithPrettyPrint:(BOOL)prettyPrint;


@end
