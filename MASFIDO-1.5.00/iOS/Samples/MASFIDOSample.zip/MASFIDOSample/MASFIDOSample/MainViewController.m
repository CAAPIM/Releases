//
//  MainViewController.m
//  MASFIDOSample
//
//  Created by YUSSY01 on 20/04/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import "MainViewController.h"

#import <MASFIDO/MASFIDO.h>
#import <SVProgressHUD/SVProgressHUD.h>
#import <MASFoundation/MASFoundation.h>

#import "NSDictionary+JSONString.h"

#import "LoginViewController.h"
#import "ResultsViewController.h"

#import <AVFoundation/AVFoundation.h>


typedef enum : NSUInteger {
    MyAlertTypeLogin,
    MyAlertTypeRegistration,
    MyAlertTypeConfirmTransaction,
    MyAlertTypeDeregistration
} MyAlertType;



@interface MainViewController () <AVCaptureMetadataOutputObjectsDelegate>
{
    BOOL _isScanning;
    BOOL _isScanned;
}

@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *scanCodeButton;


@end


@implementation MainViewController


#pragma mark - View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"MAS FIDO";
    
    [self.tableView setUserInteractionEnabled:NO];
    
    [self masStartAction:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


#pragma mark - UIAlertController

- (UIAlertController *)allertControllerFor:(MyAlertType)alertType
                                     title:(NSString *)title actions:(NSArray *)actions {
    
    UIAlertController *alertController =
        [UIAlertController alertControllerWithTitle:title
                                            message:nil
                                     preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:
     ^(UITextField * _Nonnull textField) {
         
         [textField setPlaceholder:@"Username"];
         
         [textField setTextColor:[UIColor darkGrayColor]];
         
         [textField setTextAlignment:NSTextAlignmentCenter];
         
         [textField setBorderStyle:UITextBorderStyleRoundedRect];
     }];
    
    if (alertType == MyAlertTypeLogin) {
        
        [alertController addTextFieldWithConfigurationHandler:
         ^(UITextField * _Nonnull textField) {
             
             [textField setPlaceholder:@"Password"];
             
             [textField setSecureTextEntry:YES];
             
             [textField setTextColor:[UIColor darkGrayColor]];
             
             [textField setTextAlignment:NSTextAlignmentCenter];
             
             [textField setBorderStyle:UITextBorderStyleRoundedRect];
         }];
    }
    
    for (UIAlertAction *action in actions) {
        
        [alertController addAction:action];
    }
    
    return alertController;
}

#pragma mark - UITableView Delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.section) {
            
        case 0:
            
            if (indexPath.row == 0) {
                
                [self fetchProducts];
            }
            else if (indexPath.row == 1) {
                
                [self fetchInfo];
            }
            else if (indexPath.row == 2) {
                
                [self fetchInfoWithTransactionConfirmation:nil];
            }
            
            break;
            
        case 1:
            
            if (indexPath.row == 0) {
                
                [self fidoRegisterOperation];
            }
            else if (indexPath.row == 1) {
                
                [self fidoDeregisterOperation];
            }
            else if (indexPath.row == 2) {
                
                [self fidoDeregisterOperationAAID];
            }
            
            break;
            
        case 2:
            
            if (indexPath.row == 0) {
                
                [self masUserLogout];
            }
            else if (indexPath.row == 1) {
            
                [self masDeviceDeregister];
            }
            else if (indexPath.row) {
            
                [self masDeviceResetLocally];
            }
            
            break;
            
        default:
            
            break;
    }
}

#pragma mark - Protected API

- (void)fetchProducts {
 
    [SVProgressHUD setContainerView:self.view];
    
    [SVProgressHUD showWithStatus:@"Loading ..."];
    
    [MAS getFrom:@"/protected/resource/products"
  withParameters:[NSDictionary dictionaryWithObjectsAndKeys:@"listProducts", @"operation", nil]
      andHeaders:nil
      completion:
     ^(NSDictionary<NSString *,id> * _Nullable responseInfo, NSError * _Nullable error) {
         
         [SVProgressHUD dismiss];
         
         if (responseInfo && !error) {
             
             if ([responseInfo[@"MASResponseInfoBodyInfoKey"] isKindOfClass:[NSDictionary class]] &&
                 [[responseInfo[@"MASResponseInfoBodyInfoKey"] allKeys] containsObject:@"products"]) {
                 
                 ResultsViewController *rvc =
                 [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ResultsViewController"];
                 
                 rvc.otpProtected = NO;
                 
                 rvc.productList = responseInfo[@"MASResponseInfoBodyInfoKey"][@"products"];
                 
                 [self.navigationController pushViewController:rvc animated:YES];
             }
             else {
                 
                 NSData *bodyInfo = responseInfo[@"MASResponseInfoBodyInfoKey"];
                 
                 NSString *bodyInfoStr = [[NSString alloc] initWithData:bodyInfo encoding:NSUTF8StringEncoding];
                 
                 if ([bodyInfoStr containsString:@"products"]) {
                     
                     NSArray *productsJsonComponents = [bodyInfoStr componentsSeparatedByString:@"]"];
                     NSString *productsJson = [(NSString *)[productsJsonComponents objectAtIndex:0] stringByAppendingString:@"]}"];
                     
                     NSError *jsonError = nil;
                     NSDictionary *productsDict =
                     [NSJSONSerialization JSONObjectWithData:[productsJson dataUsingEncoding:NSUTF8StringEncoding]
                                                     options:0 error:&jsonError];
                     
                     if (productsDict && !jsonError) {
                         
                         ResultsViewController *rvc =
                         [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ResultsViewController"];
                         
                         rvc.otpProtected = NO;
                         
                         rvc.productList = productsDict[@"products"];
                         
                         [self.navigationController pushViewController:rvc animated:YES];
                     }
                 }
                 else {
                     
                     UIAlertController *alert =
                     [UIAlertController alertControllerWithTitle:@"Error Info"
                                                         message:@"Invalid response info"
                                                  preferredStyle:UIAlertControllerStyleAlert];
                     
                     
                     [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                               style:UIAlertActionStyleDefault handler:nil]];
                     
                     [self.navigationController presentViewController:alert animated:YES completion:nil];
                 }
             }
         }
         else {
          
             UIAlertController *alert =
             [UIAlertController alertControllerWithTitle:@"Error Info"
                                                 message:[[error userInfo] jsonStringWithPrettyPrint:YES]
                                          preferredStyle:UIAlertControllerStyleAlert];
             
             
             [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault handler:nil]];
             
             [self.navigationController presentViewController:alert animated:YES completion:nil];
         }
     }];
}

- (void)fetchInfo {
 
    [SVProgressHUD setContainerView:self.view];
    
    [SVProgressHUD showWithStatus:@"Loading ..."];
    
    [MAS getFrom:@"/otpProtected"
  withParameters:nil andHeaders:nil
      completion:
     ^(NSDictionary<NSString *,id> * _Nullable responseInfo, NSError * _Nullable error) {
         
         [SVProgressHUD dismiss];
         
         if (responseInfo && !error) {
             
             ResultsViewController *rvc =
             [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ResultsViewController"];
             
             rvc.otpProtected = YES;
             
             rvc.productList = responseInfo[@"MASResponseInfoBodyInfoKey"][@"quotes"];
             
             [self.navigationController pushViewController:rvc animated:YES];
         }
         else {
             
             UIAlertController *alert =
             [UIAlertController alertControllerWithTitle:@"Error Info"
                                                 message:[error localizedDescription]
                                          preferredStyle:UIAlertControllerStyleAlert];
             
             
             [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault handler:nil]];
             
             [self.navigationController presentViewController:alert animated:YES completion:nil];
         }
     }];
}

- (void)fetchInfoWithTransactionConfirmation:(NSString *)trxKey {
    
    [SVProgressHUD setContainerView:self.view];
    
    [SVProgressHUD showWithStatus:@"Loading ..."];
    
    NSDictionary *headerInfo = nil;
    if (trxKey) {
        
        headerInfo = [NSDictionary dictionaryWithObjectsAndKeys:trxKey, @"x-fido-trx-key", nil];
    }
    
    [MAS getFrom:@"/protected/resource/products/fidoTrxValidation"
  withParameters:[NSDictionary dictionaryWithObjectsAndKeys:@"listProducts", @"operation", nil]
                                                 andHeaders:headerInfo completion:^(NSDictionary<NSString *,id> * _Nullable responseInfo, NSError * _Nullable error) {
                
        [SVProgressHUD dismiss];
                                                     
        if (responseInfo && !error) {
            
            if ([responseInfo[@"MASResponseInfoBodyInfoKey"] isKindOfClass:[NSDictionary class]] &&
                [[responseInfo[@"MASResponseInfoBodyInfoKey"] allKeys] containsObject:@"products"]) {
                
                ResultsViewController *rvc =
                [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ResultsViewController"];
                
                rvc.otpProtected = NO;
                
                rvc.productList = responseInfo[@"MASResponseInfoBodyInfoKey"][@"products"];
                
                [self.navigationController pushViewController:rvc animated:YES];
            }
            else if([[responseInfo[@"MASResponseInfoHeaderInfoKey"] allKeys] containsObject:@"x-ca-err"]) {
                
                NSString *magErrorCode = nil;
                
                //
                // Check if MAG error code exists
                //
                if ([[responseInfo[@"MASResponseInfoHeaderInfoKey"] allKeys] containsObject:@"x-ca-err"])
                {
                    magErrorCode = [NSString stringWithFormat:@"%@",
                                    [responseInfo[@"MASResponseInfoHeaderInfoKey"] objectForKey:@"x-ca-err"]];
                }
                
                __block UIAlertController *alert = nil;
                
                if (magErrorCode && [magErrorCode hasSuffix:@"6001217"]) {
                    
                    NSString *trxMessage =
                    [NSString stringWithFormat:@"%@",
                        [responseInfo[@"MASResponseInfoHeaderInfoKey"] objectForKey:@"x-fido-trx-msg"]];
                    
                    alert =
                    [UIAlertController alertControllerWithTitle:@"Please confirm !!"
                                                        message:trxMessage
                                                 preferredStyle:UIAlertControllerStyleAlert];
                    
                    [alert addTextFieldWithConfigurationHandler:
                     ^(UITextField * _Nonnull textField) {
                         
                         [textField setPlaceholder:@"Customize your message !!"];
                         
                         [textField setTextColor:[UIColor darkGrayColor]];
                         
                         [textField setTextAlignment:NSTextAlignmentCenter];
                         
                         [textField setBorderStyle:UITextBorderStyleRoundedRect];
                     }];
                    
                    
                    [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                              style:UIAlertActionStyleDestructive
                                                            handler:
                                      ^(UIAlertAction * _Nonnull action) {
                                          
                                          NSString *txnMsg = [[alert textFields] objectAtIndex:0].text.length ?
                                          [[alert textFields] objectAtIndex:0].text : trxMessage;
                                          if ([MASUser currentUser]) {
                                              
                                              [MASUser confirmTransactionWithFIDOUserName:[[MASUser currentUser] userName] message:txnMsg completion:
                                               ^(NSDictionary<NSString *,id> * _Nullable responseInfo,
                                                 NSError * _Nullable error) {
                                                   
                                                   if (responseInfo[@"fido_sdk"][@"server"][@"responseHeader"][@"x-fido-trx-key"]) {
                                                       
                                                       [self fetchInfoWithTransactionConfirmation:responseInfo[@"fido_sdk"][@"server"][@"responseHeader"][@"x-fido-trx-key"]];
                                                       
                                                       return ;
                                                   }
                                                   
                                                   alert =
                                                   [UIAlertController alertControllerWithTitle:@"Error Info"
                                                                                       message:[error localizedDescription]
                                                                                preferredStyle:UIAlertControllerStyleAlert];
                                                   
                                                   
                                                   [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                                                             style:UIAlertActionStyleDefault handler:nil]];
                                                   
                                                   [self.navigationController presentViewController:alert animated:YES completion:nil];
                                                   
                                               }];
                                          }
                                          
                                      }]];
                    
                    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel"
                                                              style:UIAlertActionStyleCancel handler:nil]];
                    
                    [self.navigationController presentViewController:alert animated:YES completion:nil];
                }
                else {
                    
                    alert =
                    [UIAlertController alertControllerWithTitle:@"Error Info"
                                                        message:[error localizedDescription]
                                                 preferredStyle:UIAlertControllerStyleAlert];
                    
                    
                    [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                              style:UIAlertActionStyleDefault handler:nil]];
                    
                    [self.navigationController presentViewController:alert animated:YES completion:nil];
                }
                
                for (UIView* textfield in alert.textFields) {
                    UIView *container = textfield.superview;
                    UIView *effectView = container.superview.subviews[0];
                    
                    if (effectView && [effectView class] == [UIVisualEffectView class]){
                        
                        container.backgroundColor = [UIColor clearColor];
                        [effectView removeFromSuperview];
                    }
                }
            }
            else {
                
                NSData *bodyInfo = responseInfo[@"MASResponseInfoBodyInfoKey"];
                
                NSString *bodyInfoStr = [[NSString alloc] initWithData:bodyInfo encoding:NSUTF8StringEncoding];
                
                if ([bodyInfoStr containsString:@"products"]) {
                    
                    NSArray *productsJsonComponents = [bodyInfoStr componentsSeparatedByString:@"]"];
                    NSString *productsJson = [(NSString *)[productsJsonComponents objectAtIndex:0] stringByAppendingString:@"]}"];
                    
                    NSError *jsonError = nil;
                    NSDictionary *productsDict =
                    [NSJSONSerialization JSONObjectWithData:[productsJson dataUsingEncoding:NSUTF8StringEncoding]
                                                    options:0 error:&jsonError];
                    
                    if (productsDict && !jsonError) {
                        
                        ResultsViewController *rvc =
                        [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ResultsViewController"];
                        
                        rvc.otpProtected = NO;
                        
                        rvc.productList = productsDict[@"products"];
                        
                        [self.navigationController pushViewController:rvc animated:YES];
                    }
                }
                else {
                    
                    UIAlertController *alert =
                    [UIAlertController alertControllerWithTitle:@"Error Info"
                                                        message:@"Invalid response info"
                                                 preferredStyle:UIAlertControllerStyleAlert];
                    
                    
                    [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                              style:UIAlertActionStyleDefault handler:nil]];
                    
                    [self.navigationController presentViewController:alert animated:YES completion:nil];
                }
            }
        }
        else {
            
            NSDictionary *responseInfo = [[error userInfo] objectForKey:MASResponseInfoHeaderInfoKey];
            
            NSString *magErrorCode = nil;
            
            //
            // Check if MAG error code exists
            //
            if ([[responseInfo allKeys] containsObject:@"x-ca-err"])
            {
                magErrorCode = [NSString stringWithFormat:@"%@", [responseInfo objectForKey:@"x-ca-err"]];
            }
            
            __block UIAlertController *alert = nil;
            
            if (magErrorCode && [magErrorCode hasSuffix:@"6001217"]) {
                
                NSString *trxMessage =
                    [NSString stringWithFormat:@"%@", [responseInfo objectForKey:@"x-fido-trx-msg"]];
                
                alert =
                    [UIAlertController alertControllerWithTitle:@"Please confirm !!"
                                                        message:trxMessage
                                                 preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addTextFieldWithConfigurationHandler:
                 ^(UITextField * _Nonnull textField) {
                    
                     [textField setPlaceholder:@"Customize your message !!"];
                     
                     [textField setTextColor:[UIColor darkGrayColor]];
                     
                     [textField setTextAlignment:NSTextAlignmentCenter];
                     
                     [textField setBorderStyle:UITextBorderStyleRoundedRect];
                }];
                
                
                [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                          style:UIAlertActionStyleDestructive
                                                        handler:
                                  ^(UIAlertAction * _Nonnull action) {
                                      
                                      NSString *txnMsg = [[alert textFields] objectAtIndex:0].text.length ?
                                        [[alert textFields] objectAtIndex:0].text : trxMessage;
                                      if ([MASUser currentUser]) {
                                          
                                          [MASUser confirmTransactionWithFIDOUserName:[[MASUser currentUser] userName] message:txnMsg completion:
                                           ^(NSDictionary<NSString *,id> * _Nullable responseInfo,
                                             NSError * _Nullable error) {
                                              
                                               if (responseInfo[@"fido_sdk"][@"server"][@"responseHeader"][@"x-fido-trx-key"]) {
                                                   
                                                   [self fetchInfoWithTransactionConfirmation:responseInfo[@"fido_sdk"][@"server"][@"responseHeader"][@"x-fido-trx-key"]];
                                                   
                                                   return ;
                                               }
                                               
                                               alert =
                                               [UIAlertController alertControllerWithTitle:@"Error Info"
                                                                                   message:[error localizedDescription]
                                                                            preferredStyle:UIAlertControllerStyleAlert];
                                               
                                               
                                               [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                                                         style:UIAlertActionStyleDefault handler:nil]];
                                               
                                               [self.navigationController presentViewController:alert animated:YES completion:nil];
                                               
                                          }];
                                      }
                                      
                                  }]];
                
                [alert addAction:[UIAlertAction actionWithTitle:@"Cancel"
                                                          style:UIAlertActionStyleCancel handler:nil]];
                
                [self.navigationController presentViewController:alert animated:YES completion:nil];
            }
            else {
             
                alert =
                    [UIAlertController alertControllerWithTitle:@"Error Info"
                                                        message:[error localizedDescription]
                                                 preferredStyle:UIAlertControllerStyleAlert];
                
                
                [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                          style:UIAlertActionStyleDefault handler:nil]];
                
                [self.navigationController presentViewController:alert animated:YES completion:nil];
            }
            
            for (UIView* textfield in alert.textFields) {
                UIView *container = textfield.superview;
                UIView *effectView = container.superview.subviews[0];
                
                if (effectView && [effectView class] == [UIVisualEffectView class]){
                    
                    container.backgroundColor = [UIColor clearColor];
                    [effectView removeFromSuperview];
                }
            }
        }
    }];
}


#pragma mark - LoginView

- (void)showLoginViewWithAuthCredentialsBlock:(MASAuthCredentialsBlock)authCredentialsBlock
                                        error:(NSError *)error
                                   completion:(MASCompletionErrorBlock)completion {
    
    LoginViewController *_loginViewController_ =
        [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    
    _loginViewController_.authCredentialsBlock = nil;
    
    _loginViewController_.completionBlock = nil;
    
    _loginViewController_.authCredentialsBlock = authCredentialsBlock;
    
    _loginViewController_.completionBlock = completion;
    
    _loginViewController_.error = error;
    
    MASAuthenticationProvider *qrCodeAuthenticationProvider;
    NSMutableArray *authProviders = [NSMutableArray new];
    for(MASAuthenticationProvider *provider in [MASAuthenticationProviders currentProviders].providers)
    {
        if([provider.identifier isEqualToString:@"qrcode"])
        {
            qrCodeAuthenticationProvider = provider;
            continue;
        }
        
        [authProviders addObject:provider];
    }
    
    _loginViewController_.availableProvider = [MASAuthenticationProviders currentProviders].idp;
    _loginViewController_.socialLoginAuthenticationProviders = authProviders;
    _loginViewController_.proximityLoginProvider = qrCodeAuthenticationProvider;
    
    //
    // Show the controller
    //
//    __block UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:_loginViewController_];
//    
//    //
//    // Notify view controller for handle UI refresh
//    //
//    [_loginViewController_ viewWillReload];
//    
//    [UIAlertController rootViewController].modalTransitionStyle = UIModalTransitionStyleCoverVertical;
//    
//    [[UIAlertController rootViewController] presentViewController:navigationController animated:YES
//                                                       completion:^{
//                                                           
//                                                           [_loginViewController_ viewDidReload];
//                                                           navigationController = nil;
//                                                       }];
    
    [self.navigationController presentViewController:_loginViewController_ animated:YES completion:nil];
}


#pragma mark - FIDO Operations

- (void)fidoRegisterOperation {
    
    __block UIAlertController *weakRegistrationController = nil;
    
    UIAlertAction *registerAction =
    [UIAlertAction actionWithTitle:@"FIDO Register"
                             style:UIAlertActionStyleDefault
                           handler:
     ^(UIAlertAction * _Nonnull action) {
         
         [SVProgressHUD setContainerView:self.view];
         
         [SVProgressHUD showWithStatus:@"Registering ..."];
         
         [MASUser registerWithFIDOUserName:weakRegistrationController.textFields.firstObject.text
                                completion:
          ^(NSDictionary<NSString *,id> * _Nullable responseInfo, NSError * _Nullable error) {
              
              [SVProgressHUD dismiss];
              
              UIAlertController *alert = nil;
              if (responseInfo && !error) {
                  
                  alert = [UIAlertController alertControllerWithTitle:@"FIDO Registration Successful"
                                                              message:[responseInfo jsonStringWithPrettyPrint:YES]
                                                       preferredStyle:UIAlertControllerStyleAlert];
              }
              else {
                  
                  alert = [UIAlertController alertControllerWithTitle:@"FIDO Registration Error"
                                                              message:[[error userInfo] jsonStringWithPrettyPrint:YES]
                                                       preferredStyle:UIAlertControllerStyleAlert];
              }
              
              [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                        style:UIAlertActionStyleDefault handler:nil]];
              
              [self.navigationController presentViewController:alert animated:YES completion:nil];
              
          }];
     }];
    
    UIAlertAction *cancelAction =
    [UIAlertAction actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleCancel
                           handler:
     ^(UIAlertAction * _Nonnull action) {
         
         // TODO: Cancel
     }];
    
    weakRegistrationController =
        (UIAlertController *)[self allertControllerFor:MyAlertTypeRegistration
                                                 title:@"FIDO Registration"
                                               actions:
                              [NSArray arrayWithObjects:registerAction, cancelAction, nil]];
    
    [self.navigationController presentViewController:weakRegistrationController animated:YES completion:nil];
    
    for (UIView* textfield in weakRegistrationController.textFields) {
        UIView *container = textfield.superview;
        UIView *effectView = container.superview.subviews[0];
        
        if (effectView && [effectView class] == [UIVisualEffectView class]){
            
            container.backgroundColor = [UIColor clearColor];
            [effectView removeFromSuperview];
        }
    }
}

- (void)fidoDeregisterOperation {
 
    __block UIAlertController *weakRegistrationController = nil;
    
    UIAlertAction *registerAction =
    [UIAlertAction actionWithTitle:@"FIDO Deregister"
                             style:UIAlertActionStyleDefault
                           handler:
     ^(UIAlertAction * _Nonnull action) {
         
         [SVProgressHUD setContainerView:self.view];
         
         [SVProgressHUD showWithStatus:@"Deregistering ..."];
         
         [MASUser deregisterWithFIDOUserName:weakRegistrationController.textFields.firstObject.text
                                  completion:
          ^(NSDictionary<NSString *,id> * _Nullable responseInfo, NSError * _Nullable error) {
             
              [SVProgressHUD dismiss];
              
              UIAlertController *alert = nil;
              if (responseInfo && !error) {
                  
                  alert = [UIAlertController alertControllerWithTitle:@"FIDO Deregistration"
                                                              message:[responseInfo jsonStringWithPrettyPrint:YES]
                                                       preferredStyle:UIAlertControllerStyleAlert];
              }
              else {
                  
                  alert = [UIAlertController alertControllerWithTitle:@"FIDO Deregistration Error"
                                                              message:[[error userInfo] jsonStringWithPrettyPrint:YES]
                                                       preferredStyle:UIAlertControllerStyleAlert];
              }
              
              [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                        style:UIAlertActionStyleDefault handler:nil]];
              
              [self.navigationController presentViewController:alert animated:YES completion:nil];
         }];
     }];
    
    UIAlertAction *cancelAction =
    [UIAlertAction actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleCancel
                           handler:
     ^(UIAlertAction * _Nonnull action) {
         
         // TODO: Cancel
     }];
    
    weakRegistrationController =
    (UIAlertController *)[self allertControllerFor:MyAlertTypeRegistration
                                             title:@"FIDO Deregistration"
                                           actions:
                          [NSArray arrayWithObjects:registerAction, cancelAction, nil]];
    
    [self.navigationController presentViewController:weakRegistrationController animated:YES completion:nil];
    
    for (UIView* textfield in weakRegistrationController.textFields) {
        UIView *container = textfield.superview;
        UIView *effectView = container.superview.subviews[0];
        
        if (effectView && [effectView class] == [UIVisualEffectView class]){
            
            container.backgroundColor = [UIColor clearColor];
            [effectView removeFromSuperview];
        }
    }
}


- (void)fidoDeregisterOperationAAID {
 
    __block UIAlertController *weakRegistrationController = nil;
    
    UIAlertAction *registerAction =
    [UIAlertAction actionWithTitle:@"FIDO Deregister"
                             style:UIAlertActionStyleDefault
                           handler:
     ^(UIAlertAction * _Nonnull action) {
         
         [SVProgressHUD setContainerView:self.view];
         
         [SVProgressHUD showWithStatus:@"Deregistering ..."];
         
         [MASUser deregisterAAIDsForFIDOUserName:weakRegistrationController.textFields.firstObject.text
                                      completion:
          ^(NSDictionary<NSString *,id> * _Nullable responseInfo, NSError * _Nullable error) {
             
              [SVProgressHUD dismiss];
              
              UIAlertController *alert = nil;
              if (responseInfo && !error) {
                  
                  alert = [UIAlertController alertControllerWithTitle:@"FIDO Deregistration"
                                                              message:[responseInfo jsonStringWithPrettyPrint:YES]
                                                       preferredStyle:UIAlertControllerStyleAlert];
              }
              else {
                  
                  alert = [UIAlertController alertControllerWithTitle:@"FIDO Deregistration Error"
                                                              message:[[error userInfo] jsonStringWithPrettyPrint:YES]
                                                       preferredStyle:UIAlertControllerStyleAlert];
              }
              
              [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                        style:UIAlertActionStyleDefault handler:nil]];
              
              [self.navigationController presentViewController:alert animated:YES completion:nil];
         }];
     }];
    
    UIAlertAction *cancelAction =
    [UIAlertAction actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleCancel
                           handler:
     ^(UIAlertAction * _Nonnull action) {
         
         // TODO: Cancel
     }];
    
    weakRegistrationController =
    (UIAlertController *)[self allertControllerFor:MyAlertTypeRegistration
                                             title:@"FIDO Deregistration"
                                           actions:
                          [NSArray arrayWithObjects:registerAction, cancelAction, nil]];
    
    [self.navigationController presentViewController:weakRegistrationController animated:YES completion:nil];
    
    for (UIView* textfield in weakRegistrationController.textFields) {
        UIView *container = textfield.superview;
        UIView *effectView = container.superview.subviews[0];
        
        if (effectView && [effectView class] == [UIVisualEffectView class]){
            
            container.backgroundColor = [UIColor clearColor];
            [effectView removeFromSuperview];
        }
    }
}


#pragma mark - MAS Operations

- (IBAction)masStartAction:(id)sender {
    
    [MAS setGrantFlow:MASGrantFlowPassword];
    
    [MAS setUserAuthCredentials:
     ^(MASAuthCredentialsBlock  _Nonnull authCredentialBlock) {
         
         [self showLoginViewWithAuthCredentialsBlock:authCredentialBlock
                                               error:nil
                                          completion:
          ^(BOOL completed, NSError * _Nullable error) {
              
              [SVProgressHUD dismiss];
              
              if (!completed && error) {
                  
                  [self showLoginViewWithAuthCredentialsBlock:authCredentialBlock
                                                        error:error
                                                   completion:
                   ^(BOOL completed, NSError * _Nullable error) {
                       
                       [SVProgressHUD dismiss];
                       
                       if (!completed && error) {
                           
                           [self showLoginViewWithAuthCredentialsBlock:authCredentialBlock
                                                                 error:error
                                                            completion:
                            ^(BOOL completed, NSError * _Nullable error) {
                                
                                [SVProgressHUD dismiss];
                                
                                if (!completed && error) {
                                    
                                    if (authCredentialBlock) {
                                        
                                        authCredentialBlock(nil, YES, nil);
                                    }
                                    
                                    return;
                                }
                            }];
                       }
                   }];
              }
          }];
    }];
    
    [MAS setOTPChannelSelectionBlock:
     ^(NSArray * _Nonnull supportedOTPChannels, MASOTPGenerationBlock  _Nonnull otpGenerationBlock) {
        
         NSArray * otpChannels = [NSArray arrayWithObject:@"EMAIL"];
         
         otpGenerationBlock(otpChannels, NO, nil);
    }];
    
    [MAS setOTPCredentialsBlock:
     ^(MASOTPFetchCredentialsBlock  _Nonnull otpBlock, NSError * _Nullable otpError) {
        
         UIAlertController *alert =
            [UIAlertController alertControllerWithTitle:@"One Time Password"
                                                message:@"Please enter OTP sent to your email/phone"
                                         preferredStyle:UIAlertControllerStyleAlert];
         
         [alert addTextFieldWithConfigurationHandler:
          ^(UITextField * _Nonnull textField) {
             
              textField.placeholder = @"One Time Password";
         }];
         
         [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                   style:UIAlertActionStyleDefault
                                                 handler:
                           ^(UIAlertAction * _Nonnull action) {
             
                               otpBlock(alert.textFields.firstObject.text, NO, nil);
                               
                           }]];
         
         [alert addAction:[UIAlertAction actionWithTitle:@"Cancel"
                                                   style:UIAlertActionStyleCancel
                                                 handler:
                           ^(UIAlertAction * _Nonnull action) {
             
                               otpBlock(alert.textFields.firstObject.text, YES, nil);
                           }]];
         
         [self.navigationController presentViewController:alert animated:YES completion:nil];
    }];
    
    [SVProgressHUD setContainerView:self.view];
    
    [SVProgressHUD show];
    
    [MAS startWithDefaultConfiguration:YES
                            completion:
     ^(BOOL completed, NSError * _Nullable error) {
         
         [SVProgressHUD dismiss];
         
         if (completed && !error) {
             
             [self.tableView setUserInteractionEnabled:YES];
         }
         else {
             
             UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"MAS Start Failed"
                                                         message:[error localizedDescription]
                                                  preferredStyle:UIAlertControllerStyleAlert];
             
             [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault handler:nil]];
             
             [self.navigationController presentViewController:alert animated:YES completion:nil];
         }
     }];
}


- (IBAction)masStopAction:(id)sender {

    [SVProgressHUD setContainerView:self.view];
    
    [SVProgressHUD show];
    
    [MAS stop:^(BOOL completed, NSError * _Nullable error) {
        
        [SVProgressHUD dismiss];
        
        UIAlertController *alert = nil;
        if (completed && !error) {
            
            [self.tableView setUserInteractionEnabled:NO];
            
            alert = [UIAlertController alertControllerWithTitle:@"MAS Stop Successful"
                                                        message:@"MAS Stop Successful !!"
                                                 preferredStyle:UIAlertControllerStyleAlert];
        }
        else {
            
            alert = [UIAlertController alertControllerWithTitle:@"MAS Stop Failed"
                                                        message:[error localizedDescription]
                                                 preferredStyle:UIAlertControllerStyleAlert];
        }
        
        [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                  style:UIAlertActionStyleDefault handler:nil]];
        
        [self.navigationController presentViewController:alert animated:YES completion:nil];
    }];
}


- (void)masUserLogout {
    
    __block UIAlertController *alert = nil;
    
    if ([MASUser currentUser]) {
        
        [SVProgressHUD setContainerView:self.view];
        
        [SVProgressHUD show];
        
        [[MASUser currentUser] logoutWithCompletion:
         ^(BOOL completed, NSError * _Nullable error) {
             
             [SVProgressHUD dismiss];
             
             if (completed && !error) {
                 
                 alert = [UIAlertController alertControllerWithTitle:@"MAS User Logout Successful"
                                                             message:@"MAS User Logout Successful !!"
                                                      preferredStyle:UIAlertControllerStyleAlert];
             }
             else {
                 
                 alert = [UIAlertController alertControllerWithTitle:@"MAS User Logout Failed"
                                                             message:[error localizedDescription]
                                                      preferredStyle:UIAlertControllerStyleAlert];
             }
             
             [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault handler:nil]];
             
             [self.navigationController presentViewController:alert animated:YES completion:nil];
             
         }];
    }
    else {
        
        alert = [UIAlertController alertControllerWithTitle:@"MAS User Logout Failed"
                                                    message:@"No user is currently logged in."
                                             preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                  style:UIAlertActionStyleDefault handler:nil]];
        
        [self.navigationController presentViewController:alert animated:YES completion:nil];
    }
}


- (void)masDeviceDeregister {
    
    [SVProgressHUD setContainerView:self.view];
    
    [SVProgressHUD show];
    
    [[MASDevice currentDevice] deregisterWithCompletion:
     ^(BOOL completed, NSError * _Nullable error) {
        
         [SVProgressHUD dismiss];
         
         UIAlertController *alert = nil;
         if (completed && !error) {
             
             alert = [UIAlertController alertControllerWithTitle:@"MAS Device Deregistration Successful"
                                                         message:@"MAS Device Deregistration Successful !!"
                                                  preferredStyle:UIAlertControllerStyleAlert];
         }
         else {
             
             alert = [UIAlertController alertControllerWithTitle:@"MAS Device Deregistration Failed"
                                                         message:[error localizedDescription]
                                                  preferredStyle:UIAlertControllerStyleAlert];
         }
         
         [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                   style:UIAlertActionStyleDefault handler:nil]];
         
         [self.navigationController presentViewController:alert animated:YES completion:nil];
    }];
}


- (void)masDeviceResetLocally {
    
    [[MASDevice currentDevice] resetLocally];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"MAS Device Reset Successful"
                                                message:@"MAS Device Reset Successful !!"
                                         preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                              style:UIAlertActionStyleDefault handler:nil]];
    
    [self.navigationController presentViewController:alert animated:YES completion:nil];
}


#pragma mark - QRCode

- (IBAction)scanQRCodeButtonPressed:(id)sender {
    
    if(!_isScanning){
        _session = [[AVCaptureSession alloc] init];
        AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        NSError *error = nil;
        
        AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device
                                                                            error:&error];
        if (input) {
            [_session addInput:input];
        } else {
            NSLog(@"Error: %@", error);
        }
        
        AVCaptureMetadataOutput *output = [[AVCaptureMetadataOutput alloc] init];
        [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
        [_session addOutput:output];
        [output setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]];
        
        _previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
        
        // Display full screen
        _previewLayer.frame = CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height);
        
        // Add the video preview layer to the view
        [self.view.layer addSublayer:_previewLayer];
        
        [_session startRunning];
        _isScanning = YES;
        [_scanCodeButton setTitle:@"Cancel"];
    }else if (_isScanning){
        [_session stopRunning];
        [_previewLayer removeFromSuperlayer];
        _session = nil;
        _previewLayer = nil;
        [_scanCodeButton setTitle:@"Scan Code"];
        _isScanning = NO;
    }
    
    
}


- (void)captureOutput:(AVCaptureOutput *)captureOutput
didOutputMetadataObjects:(NSArray *)metadataObjects
       fromConnection:(AVCaptureConnection *)connection
{
    NSString *QRCode = nil;
    [_session stopRunning];
    [_previewLayer removeFromSuperlayer];
    _session = nil;
    _previewLayer = nil;
    
    
    for (AVMetadataObject *metadata in metadataObjects) {
        if ([metadata.type isEqualToString:AVMetadataObjectTypeQRCode]) {
            // This will never happen; nobody has ever scanned a QR code... ever
            QRCode = [(AVMetadataMachineReadableCodeObject *)metadata stringValue];
            NSLog(@"QR Code: %@", QRCode);
            
            [MASProximityLoginQRCode authorizeAuthenticateUrl:QRCode
                                                   completion:
             ^(BOOL completed, NSError * _Nullable error) {
                
                 if (!completed && error) {
                     
                     NSLog(@"failed to authenticate with QR code: %@", error);
                     UIAlertView *alertView =   [[UIAlertView alloc] initWithTitle:@"QR code authentication"
                                                                           message:@"QR code authentication failed"
                                                                          delegate:nil
                                                                 cancelButtonTitle:@"OK"
                                                                 otherButtonTitles:nil];
                     
                     [alertView show];
                 }
            }];
            
            [_scanCodeButton setTitle:@"Scan Code"];
            break;
        }
    }
}


@end
