/*
 * Copyright (c) 2016 CA. All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 *
 */

package com.ca.samsung.license;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.app.enterprise.license.EnterpriseLicenseManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import com.sec.enterprise.knox.auditlog.AuditLog;

import java.util.Hashtable;
import java.util.List;

public class DeviceStatus {

    private static final String TAG = "CA Samsung Knox License";

    protected DeviceStatus()
    {
    }

    public static DeviceStatus getInstance()
    {
        return instance;
    }
    protected static DeviceStatus instance = new DeviceStatus();
    protected static Activity activityMain = null;

    public void setActivityMain(Activity activityMainSet)
    {
        activityMain = activityMainSet;
    }

    /**
     * Get a status description
     */
    public String getStatusDescription()
    {
        StringBuffer status = new StringBuffer();

        try {
            if (statusAdminMode != null) {
                status.append(statusAdminMode);
                status.append("\n");
            }
            if (statusKlmMode != null) {
                status.append(statusKlmMode);
                status.append("\n");
            }
            if (statusElmSdkMode != null) {
                status.append(statusElmSdkMode);
                status.append("\n");
            }
            if (! isAdminEnabled()) {
                status.append("Cannot activate ELM SDK License until Admin activated");
            } else if (auditLogCouldBeEnabled()) {
                status.append("Admin Activated, ELM SDK License is Enabled");
            } else if (auditLogCantBeEnabledEntLicNotActivated()) {
                status.append("Admin Activated, but ELM SDK License is NOT Enabled");
            } else {
                // try another way
                String pkgName = activityMain.getPackageName();
                try {
                    // try to get this api call data
                    //   if we can, the enterprise license has been activated
                    EnterpriseLicenseManager mgr = EnterpriseLicenseManager.getInstance(activityMain);
                    status.append("Admin Activated, ELM SDK License is Enabled");

                } catch (SecurityException x) {
                    // if we get a security exception that a specific permission
                    //       has not been requested, but actually was, the
                    //       enterprise license has not been activated
                    if (x.toString().contains("android.permission.sec.MDM_LICENSE_LOG")) {
                        // see if this permission is included in manifest
                        if (isPermissionRequested("android.permission.sec.MDM_LICENSE_LOG")) {
                            // permission is present, therefore license has not been activated
                            status.append("Admin Activated, but ELM SDK License is NOT Enabled");
                        } // otherwise we have no idea
                    } else
                        status.append("Admin Activated, but Unable to check ELM status: " + x);
                } catch (Exception x) {
                    // if the exception specifies that app lacks
                    //   "android.permission.sec.MDM_LICENSE_LOG"
                    // and it is in the manifest, the enterprise license
                    // has not been activated
                    status.append("Admin Activated, but Unable to check ELM status: " + x);
                }
            }
        } catch (Exception x) {
            status.append("Unable to check Admin and ELM status: " + x);
        }
        return status.toString();
    }


    /**
     * Whether or not the admin mode has been enabled on this platform.
     * @return true/false
     */
    public static boolean isAdminEnabled()
    {
        DevicePolicyManager dpm = (DevicePolicyManager) activityMain.getSystemService(Context.DEVICE_POLICY_SERVICE);
        List<ComponentName> activeAdmins = dpm.getActiveAdmins();
        if ((activeAdmins != null) && (activeAdmins.size() > 0)) {
            // search the list for ours
            ComponentName licenseDeviceAdmin = new ComponentName(activityMain, LicenseAdminReceiver.class);
            for (ComponentName comp : activeAdmins) {
                if (comp.compareTo(licenseDeviceAdmin) == 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check if audit log can't be enabled only because the enterprise
     *     license has not been activated - admin activated and
     *     the permission is available.
     * @return true / false
     */
    protected static boolean auditLogCantBeEnabledEntLicNotActivated()
    {
        boolean returnValue = false;
        // if we're running in Knox container, we can't enter ELM SDK license anyway
        if (! isAdminEnabled())
            returnValue = false;
            // if app hasn't requested audit log permissions
        else if (! isPermissionRequested("android.permission.sec.MDM_AUDIT_LOG"))
            returnValue = false;
        else {
            try {
                AuditLog auditLogService = AuditLog.getInstance(activityMain);
                if (auditLogService.isAuditLogEnabled())
                    returnValue = false;
                else
                    returnValue = false;
            } catch (SecurityException s) {
                // if the permission is present, Admin is activated, but we get SecurityException,
                //     then the only problem is with the ELM SDK License
                if (s.toString().contains("android.permission.sec.MDM_AUDIT_LOG"))
                    returnValue = true;
            } catch (Exception x) {
                returnValue = false;
            }
        }
        return returnValue;
    }

    /**
     * Check if audit log can be enabled, which proves that
     *     the Enterprise SDK license has been activated
     * @return true / false
     */
    protected static boolean auditLogCouldBeEnabled()
    {
        boolean returnValue = false;
        // if we're running in Knox container, we can't enter ELM SDK license anyway
        if (! isAdminEnabled())
            returnValue = false;
            // if app hasn't requested audit log permissions
        else if (! isPermissionRequested("android.permission.sec.MDM_AUDIT_LOG"))
            returnValue = false;
        else {
            try {
                AuditLog auditLogService = AuditLog.getInstance(activityMain);
                if (auditLogService.isAuditLogEnabled())
                    returnValue = true;
                else
                    returnValue = true;
            } catch (Exception x) {
                returnValue = false;
            }
        }
        return returnValue;
    }

    /**
     * Check if a specific permission is present
     */
    public static boolean isPermissionRequested(String permission)
    {
        Hashtable<String, String> appPermissions = null;
        try {
            PackageManager pm = activityMain.getPackageManager();
            String pkgName = activityMain.getPackageName();
            PackageInfo packageInfo = pm.getPackageInfo(pkgName, PackageManager.GET_PERMISSIONS);
            String[] requestedPermissions = packageInfo.requestedPermissions;
            if (requestedPermissions != null) {
                appPermissions = new Hashtable<String, String>();
                for (String requestedPermission : requestedPermissions)
                    appPermissions.put(requestedPermission, requestedPermission);
            }
        } catch (Exception noPermissions) {
            Log.i(TAG, "isPermissionRequested unable to get permission list, ", noPermissions);
        }
        if (appPermissions != null)
            if (appPermissions.get(permission) != null)
                return true;
        return false;
    }

    protected String statusAdminMode = null;
    public void setStatusAdminMode(String mode)
    {
        statusAdminMode = mode;
    }
    protected String statusKlmMode = null;
    public void setStatusKlmMode(String mode)
    {
        statusKlmMode = mode;
    }
    protected String statusElmSdkMode = null;
    public void setStatusElmSdkMode(String mode)
    {
        statusElmSdkMode = mode;
    }

}
