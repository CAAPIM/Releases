/*
 * Copyright (c) 2016 CA. All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 *
 */

package com.ca.samsung.license;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.net.*;

import com.sec.enterprise.knox.license.KnoxEnterpriseLicenseManager;
import android.app.enterprise.license.EnterpriseLicenseManager;

public class ExampleActivity extends FragmentActivity {
    private static final String TAG = "CA Samsung Knox License";

    public static TextView screenOutput = null;
    ProgressBar progressBar;

    protected static final String magHost = "http://ssg90.l7tech.com:8080";

    protected static Activity activityMain = null;


    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Initialize components
        activityMain = this;
        screenOutput = (TextView) findViewById(R.id.screenOutput);
        // allow the broadcast intent receiver to write to screenOutput
        LicenseAdminReceiver.handler = new Handler();
        DeviceStatus.getInstance().setActivityMain(activityMain);


        if (savedInstanceState != null) {
            try {
                progressBar.setVisibility(ProgressBar.VISIBLE);
            } catch (Exception badProgress) {
                Log.i(TAG, "Unable to set progress bar: " + badProgress);
            }
        }



        final Button button1One = (Button) findViewById(R.id.btn1One);
        final Button button2Two = (Button) findViewById(R.id.btn2Two);
        final Button button3Three = (Button) findViewById(R.id.btn3Three);
        final Button button4Four = (Button) findViewById(R.id.btn4Four);
        final Button button5Five = (Button) findViewById(R.id.btn5Five);


        button1One.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // set admin mode
                    screenOutput.setText("Activating Admin Rights");

                    int request = 1; //REQUEST_ENABLE;
                    ComponentName caLicenseDeviceAdmin = new ComponentName(activityMain, LicenseAdminReceiver.class);
                    Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, caLicenseDeviceAdmin);
                    intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Additional text explaining why this needs to be added.");
                    activityMain.startActivityForResult(intent, request);

                    button1One.getBackground().setColorFilter(Color.DKGRAY, PorterDuff.Mode.MULTIPLY);
                    button2Two.getBackground().setColorFilter(Color.CYAN, PorterDuff.Mode.MULTIPLY);
                    button3Three.getBackground().setColorFilter(Color.CYAN, PorterDuff.Mode.MULTIPLY);
                    button1One.invalidate();
                    button2Two.invalidate();
                    button3Three.invalidate();

                } catch (Exception x) {
                    Log.w(TAG, "Unable to activate admin mode: ", x);
                }
            }
        });
        button1One.getBackground().setColorFilter(Color.CYAN, PorterDuff.Mode.MULTIPLY);



        button2Two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // set Knox
                    TextView screenOutput = (TextView) findViewById(R.id.screenOutput);
                    screenOutput.setText("Activating Knox License");

                    new GetLicenseTask().execute(magHost + "/samsungKnoxLicense", LicenseAdminReceiver.handler);

                    button2Two.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.MULTIPLY);
                    button2Two.invalidate();
                    button4Four.getBackground().setColorFilter(Color.CYAN, PorterDuff.Mode.MULTIPLY);
                    button4Four.invalidate();

                } catch (Exception x) {
                    Log.w(TAG, "Unable to request Knox License from "
                            + magHost + "/samsungEnterpriseLicense : " + x);
                }
            }
        });
        button2Two.getBackground().setColorFilter(Color.DKGRAY, PorterDuff.Mode.MULTIPLY);



        button3Three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // set Enterprise SDK
                    TextView screenOutput = (TextView) findViewById(R.id.screenOutput);
                    screenOutput.setText("Activating Enterprise License");

                    new GetLicenseTask().execute(magHost + "/samsungEnterpriseLicense", LicenseAdminReceiver.handler);

                    button3Three.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.MULTIPLY);
                    button3Three.invalidate();
                    button4Four.getBackground().setColorFilter(Color.CYAN, PorterDuff.Mode.MULTIPLY);
                    button4Four.invalidate();

                } catch (Exception x) {
                    Log.w(TAG, "Unable to request Enterprise License from "
                            + magHost + "/samsungEnterpriseLicense : " + x);
                }
            }
        });
        button3Three.getBackground().setColorFilter(Color.DKGRAY, PorterDuff.Mode.MULTIPLY);



        button4Four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // show status
                    screenOutput.setText("Disabling Admin Rights to allow app uninstall");

                    ComponentName devAdminReceiver = new ComponentName(activityMain, LicenseAdminReceiver.class);
                    DevicePolicyManager dpm = (DevicePolicyManager) activityMain.getSystemService(Context.DEVICE_POLICY_SERVICE);
                    dpm.removeActiveAdmin(devAdminReceiver);

                    button4Four.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.MULTIPLY);
                    button4Four.invalidate();
                    button1One.getBackground().setColorFilter(Color.CYAN, PorterDuff.Mode.MULTIPLY);
                    button1One.invalidate();

                } catch (Exception x) {
                    Log.w(TAG, "Attestation Unable to initiate attestation: ", x);
                }
            }
        });
        button4Four.getBackground().setColorFilter(Color.DKGRAY, PorterDuff.Mode.MULTIPLY);


        button5Five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // show status
                    screenOutput.setText(DeviceStatus.getInstance().getStatusDescription());

                } catch (Exception x) {
                    Log.w(TAG, "Attestation Unable to initiate attestation: ", x);
                }
            }
        });
        button5Five.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.MULTIPLY);

    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public void showMessage(final String message, final int toastLength) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(ExampleActivity.this, message, toastLength).show();
            }
        });
    }


    protected class GetLicenseTask extends AsyncTask<Object, Void, String> {

        protected String doInBackground(Object... urls) {
            try {
                String ssgApi = (String) urls[0];
                Handler handler = (Handler) urls[1];

                String license = getUrlContent(ssgApi, handler);

                final String licenseToPrint = license
                           .replaceAll("[0-9]", "X").replaceAll("[A-Z]", "X");

                if (license.length() > 100) {
                    // Enterprise licenses are typically 128 alphanumeric characters
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ExampleActivity.screenOutput.setText("Activating Enterprise License ("
                                        + licenseToPrint + ")");
                            } catch (Exception x) {
                                Log.w(TAG, "Unable to send 'Activating Enterprise License' to screenOutput: " + x);
                            }
                        }
                    });

                    // perform activation
                    EnterpriseLicenseManager licenseMgr
                            = EnterpriseLicenseManager.getInstance(activityMain);
                    licenseMgr.activateLicense(license);

                } else {
                    // knox licenses are of the form KLMXX-XXXXX-XXXXX-XXXXX-XXXXX-XXXXX
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ExampleActivity.screenOutput.setText("Activating Knox License ("
                                        + licenseToPrint + ")");
                            } catch (Exception x) {
                                Log.w(TAG, "Unable to send 'Activating Knox License' to screenOutput: " + x);
                            }
                        }
                    });

                    // Activate the license
                    KnoxEnterpriseLicenseManager klm = KnoxEnterpriseLicenseManager.getInstance(activityMain);
                    klm.activateLicense(license);
                }
            } catch (Exception e) {
                Log.w(TAG, "License Activation error: " + e);
            }
            return "done";
        }

        protected void onPostExecute(String str) {
        }
    }


    /**
     * Retrieve license from URL
     *
     * @param ssgApi
     * @return
     */
    public static String getUrlContent(String ssgApi, Handler handler) {
        HttpURLConnection urlConnection = null;
        BufferedInputStream in = null;
        StringBuffer sb = new StringBuffer();
        try {
            Log.i(TAG, "getUrlContent retrieving from " + ssgApi);
            URL url = new URL(ssgApi);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setConnectTimeout(4000);
            urlConnection.setReadTimeout(8000);
            urlConnection.setDoOutput(true);

            in = new BufferedInputStream(urlConnection.getInputStream());

            // get the content
            int count = 0;
            byte data[] = new byte[256];
            while ((count = in.read(data)) >= 0) {
                sb.append(new String(data, 0, count, "UTF-8"));
            }

        } catch (Exception x) {
            final String errorResult = "Unable to retrieve license from "
                    + ssgApi + ": " + x;
            Log.w(TAG, errorResult);

            handler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        ExampleActivity.screenOutput.append("\n" + errorResult);
                    } catch (Exception x) {
                        Log.w(TAG, "Unable to send message ("
                                + errorResult + ") to screenOutput: " + x);
                    }
                }
            });

        } finally {
            try {
                if (in != null)
                    in.close();
            } catch (Exception x) {
            }
        }
        return sb.toString();
    }

}
