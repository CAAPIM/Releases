/*
 * Copyright (c) 2016 CA. All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 *
 */

package com.ca.samsung.license;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;
import android.os.Handler;

import com.sec.enterprise.knox.Attestation;
import com.sec.enterprise.knox.license.KnoxEnterpriseLicenseManager;
import android.app.enterprise.license.EnterpriseLicenseManager;

/** 
 * Example of a do-nothing admin class. When enabled, it lets you control 
 * some of its policy and reports when there is interesting activity. 
 */

public class LicenseAdminReceiver extends DeviceAdminReceiver {

    protected static String TAG = "CA Samsung Knox License Admin Receiver";

    public static Handler handler = null;

    void showToast(Context context, CharSequence msg) { 
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    } 
         
    @Override 
    public void onEnabled(Context context, Intent intent) { 
        //showToast(context, "Sample Device Admin: enabled");
        handlerAppend("\nAdmin Mode Enabled");
        DeviceStatus.getInstance().setStatusAdminMode("Admin Mode Enabled");
        Log.i(TAG, "onEnabled");
    }
    
    @Override 
    public CharSequence onDisableRequested(Context context, Intent intent) { 
        return "This is an optional message to warn the user about disabling."; 
    } 
         
    @Override 
    public void onDisabled(Context context, Intent intent) { 
        //showToast(context, "Sample Device Admin: disabled");
        handlerAppend("\nAdmin Mode Disabled");
        DeviceStatus.getInstance().setStatusAdminMode("Admin Mode DISABLED");
        Log.i(TAG, "onDisabled");
    } 
         
    @Override 
    public void onPasswordChanged(Context context, Intent intent) { 
        showToast(context, "Sample Device Admin: pw changed"); 
    } 
         
    @Override 
    public void onPasswordFailed(Context context, Intent intent) { 
        showToast(context, "Sample Device Admin: pw failed"); 
    } 

    @Override 
    public void onPasswordSucceeded(Context context, Intent intent) { 
        showToast(context, "Sample Device Admin: pw succeeded"); 
    }
    
    /**
     * Callback for any intents, as configured in AndroidManifest.xml
     * @param context the application context for the intent 
     * @param intent the intent or event
     * */
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Log.i(TAG, "onReceive intent start, action " + intent.getAction() + ", and extras " + intent.getExtras());

            String result = checkIfAdminModeResult(intent);
            if (result == null)
                result = checkIfKnoxLicenseResult(intent);
            if (result == null)
                result = checkIfElmSDKicenseResult(intent);
            if (result == null)
                result = "Received " + intent.getAction() + " and extras " + intent.getExtras();

            if (handler != null) {
                handlerAppend("\n" + result);
            } else
                Log.i(TAG, "LicenseAdminReceiver NOT sending command to handler!  Content: " + result);

        } catch (Exception x) {
            Log.i(TAG, "LicenseAdminReceiver Received intent, ERROR: ", x);
        }
    }

    protected void handlerAppend(final String text)
    {
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ExampleActivity.screenOutput.append(text);
                } catch (Exception x) {
                    Log.i(TAG, "LicenseAdminReceiver FAILED to send ("
                            + text + ") to screenOutput: " + x);
                }
            }
        });

    }

    /**
     * If the intent is a result of Admin Mode change,
     *      return the result as a string
     */
    public String checkIfAdminModeResult(Intent intent)
    {
        String result = null;
        try {
            if ("android.app.action.DEVICE_ADMIN_ENABLED".equals(intent.getAction()))
                result = "Admin Mode Enabled";
            else if ("android.app.action.DEVICE_ADMIN_DISABLED".equals(intent.getAction()))
                result = "Admin Mode Disabled";
        } catch (Exception x) {
            Log.i(TAG, "LicenseAdminReceiver unable to check if admin mode change: " + x);
        }
        if (result != null)
            DeviceStatus.getInstance().setStatusAdminMode(result);
        return result;
    }


    /**
     * If the intent is a result of Knox License Activation,
     *     return the result as a string
     *
     * @param intent the intent
     * @return parsed result, if any
     */
    public String checkIfKnoxLicenseResult(Intent intent)
    {
        String result = null;
        try {
            // check if knox license activation / validation complete
            if (KnoxEnterpriseLicenseManager.ACTION_LICENSE_STATUS.equals(intent.getAction())
                    || "edm.intent.action.knox_license.status".equals(intent.getAction())) {

                Log.i(TAG, "Knox License result, " + intent.getStringExtra("edm.intent.extra.knox_license.status"));

                result = "Knox License Result: UNKNOWN";

                // Get the result; try full string in case jar file string doesn't match platform
                String status = intent.getStringExtra("edm.intent.extra.knox_license.status");
                if (status == null)
                    status = intent.getStringExtra(KnoxEnterpriseLicenseManager.ACTION_LICENSE_STATUS);

                if (status != null) {
                    if (status.equals("success")) {
                        result = "Knox License Succesfully Activated";
                    }
                    else {
                        // get the error code
                        String error = "Unknown";
                        int incorrectResult = 999;
                        int intError = intent.getIntExtra("edm.intent.extra.license.errorcode", incorrectResult);
                        if (intError == incorrectResult)
                            intError = intent.getIntExtra(KnoxEnterpriseLicenseManager.EXTRA_LICENSE_ERROR_CODE, incorrectResult);

                        // parse error result
                        if (intError == KnoxEnterpriseLicenseManager.ERROR_INTERNAL)
                            error = "Knox license NOT ACTIVATED: Internal error.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_INTERNAL_SERVER)
                            error = "Knox license NOT ACTIVATED: Internal server error.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_INVALID_LICENSE)
                            error = "Knox license NOT ACTIVATED: Invalid license.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_LICENSE_DEACTIVATED)
                            error = "Knox license NOT ACTIVATED: License deactivated.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_LICENSE_EXPIRED)
                            error = "Knox license NOT ACTIVATED: License expired.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_LICENSE_QUANTITY_EXHAUSTED)
                            error = "Knox license NOT ACTIVATED: License quantity exhausted.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_LICENSE_TERMINATED)
                            error = "Knox license NOT ACTIVATED: License terminated.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_NETWORK_DISCONNECTED)
                            error = "Knox license NOT ACTIVATED: Network disconnected.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_NETWORK_GENERAL)
                            error = "Knox license NOT ACTIVATED: General network error.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_NONE)
                            error = "Knox license NOT ACTIVATED: Success.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_NULL_PARAMS)
                            error = "Knox license NOT ACTIVATED: Null parameter.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_UNKNOWN)
                            error = "Knox license NOT ACTIVATED: Unknown error.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_USER_DISAGREES_LICENSE_AGREEMENT)
                            error = "Knox license NOT ACTIVATED: User disagrees License agreement.";
                        else if (intError == KnoxEnterpriseLicenseManager.ERROR_NOT_CURRENT_DATE)
                            error = "Knox license NOT ACTIVATED: Not Current Date";
                        else
                            error = "Knox license NOT ACTIVATED: Unknown Error Code: " + intError;

                        result = "Knox License NOT Activated: " + error;
                    }
                }
            }
        } catch (Exception x) {
            Log.w(TAG, "Knox license exception parsing result (intent): ", x);
        }

        if (result != null)
            DeviceStatus.getInstance().setStatusKlmMode(result);
        return result;
    }


    /**
     * If the intent is a result of Elm SDK License Activation,
     *     return the result as a string
     *
     * @param intent the intent
     * @return parsed result, if any
     */
    public String checkIfElmSDKicenseResult(Intent intent)
    {
        String result = null;
        try {
            if (EnterpriseLicenseManager.ACTION_LICENSE_STATUS.equals(intent.getAction())
                    || "edm.intent.action.license.status".equals(intent.getAction())) {

                Log.i(TAG, "Enterprise SDK License Response: " + intent.getStringExtra("edm.intent.extra.license.status"));

                // Attempting labels + hardcoded strings, sometimes libraries
                //        on device don't match jar files
                String status = intent.getStringExtra("edm.intent.extra.license.status");
                if (status == null)
                    status = intent.getStringExtra(EnterpriseLicenseManager.EXTRA_LICENSE_STATUS);

                if (status != null) {
                    if (status.equals("success")) {
                        result = "ELM SDK License Succesfully Activated";
                        String groups = intent.getStringExtra("edm.intent.extra.license.perm_group");
                        if (groups != null)
                            result = "ELM SDK License Successfully Activated, Groups: " + groups;
                    }
                    else {
                        int incorrectResult = 999;
                        int intError = intent.getIntExtra("edm.intent.extra.license.errorcode", incorrectResult);
                        if (intError == incorrectResult)
                            intError = intent.getIntExtra(EnterpriseLicenseManager.EXTRA_LICENSE_ERROR_CODE, incorrectResult);

                        // parse error result
                        String error = "Enterprise License Activation Failure";
                        if (intError == EnterpriseLicenseManager.ERROR_INTERNAL)
                            error += ": Internal error.";
                        else if (intError == EnterpriseLicenseManager.ERROR_INTERNAL_SERVER)
                            error += ": Internal server error.";
                        else if (intError == EnterpriseLicenseManager.ERROR_INVALID_LICENSE)
                            error += ": Invalid license.";
                        else if (intError == EnterpriseLicenseManager.ERROR_LICENSE_TERMINATED)
                            error += ": License terminated.";
                        else if (intError == EnterpriseLicenseManager.ERROR_NETWORK_DISCONNECTED)
                            error += ": Network disconnected.";
                        else if (intError == EnterpriseLicenseManager.ERROR_NETWORK_GENERAL)
                            error += ": General network error.";
                        else if (intError == EnterpriseLicenseManager.ERROR_NO_MORE_REGISTRATION)
                            error += ": No more registration with this license.";
                        else if (intError == EnterpriseLicenseManager.ERROR_NULL_PARAMS)
                            error += ": Null parameter.";
                        else if (intError == EnterpriseLicenseManager.ERROR_UNKNOWN)
                            error += ": Unknown error.";
                        else if (intError == EnterpriseLicenseManager.ERROR_NONE)
                            error += ": Received status of " + status + " but error was ERROR_NONE";
                        else if (intError == EnterpriseLicenseManager.ERROR_INVALID_PACKAGE_NAME)
                            error += ": Invalid package name.";
                        else if (intError == EnterpriseLicenseManager.ERROR_NOT_CURRENT_DATE)
                            error += ": Not current date.";
                        else if (intError == EnterpriseLicenseManager.ERROR_USER_DISAGREES_LICENSE_AGREEMENT)
                            error += ": User disagrees License agreement.";
                        else
                            error += ": Unknown Error Code: " + intError;

                        result = "ELM SDK License NOT Activated: " + error;
                    }
                }
            }
        } catch (Exception x) {
            Log.w(TAG, "ELM SDK license exception parsing result (intent): ", x);
        }

        if (result != null)
            DeviceStatus.getInstance().setStatusElmSdkMode(result);
        return result;
    }


}
