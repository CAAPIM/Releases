/*
 * Copyright (c) 2016 CA. All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 *
 */

package com.ca.mas.sample.smc.controller.gcm;

import android.app.IntentService;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.ca.mas.core.service.MssoIntents;
import com.ca.mas.sample.smc.controller.ExampleActivity;
import com.ca.mas.sample.smc.controller.R;
import com.google.android.gms.gcm.GoogleCloudMessaging;

public class GcmIntentService extends IntentService {
    public static final int NOTIFICATION_ID = 1;
    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;
    private static final String TAG = "GCMIntentService";

    public GcmIntentService() {
        super("GcmIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        String contents = retrieveContents(intent);
        com.ca.mas.sample.smc.controller.ExampleActivity.receivedIntent(intent);
        GcmBroadcastReceiver.completeWakefulIntent(intent);
    }

    private void sendNotification(String contents) {
        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        Intent syncIntent = new Intent(this, ExampleActivity.class);
        syncIntent.setAction(MssoIntents.ACTION_SYNC);
        syncIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        syncIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                syncIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle("SMC Notification")
                        .setStyle(new NotificationCompat.BigTextStyle()
                                .bigText(contents))
                        .setContentText(contents);

        mBuilder.setContentIntent(contentIntent);
        mBuilder.setAutoCancel(true);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
    }
    
    protected String retrieveContents(Intent intent)
    {
        String contents = "unknown";
        try {
            Bundle extras = intent.getExtras();
            GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);
            // The getMessageType() intent parameter must be the intent you received
            // in your BroadcastReceiver.
            String messageType = gcm.getMessageType(intent);

            if (!extras.isEmpty()) {  // has effect of unparcelling Bundle
                Log.w(TAG, "Message type " + messageType + ", extras " + extras.toString());
                contents = messageType + ", extras " + extras.toString();
                /*
                 * Filter messages based on message type. Since it is likely that GCM
                 * will be extended in the future with new message types, just ignore
                 * any message types you're not interested in, or that you don't
                 * recognize.
                 */
                if (GoogleCloudMessaging.
                        MESSAGE_TYPE_SEND_ERROR.equals(messageType)) {
                    Log.w(TAG, "GCM got Send error: " + extras.toString());
                } else if (GoogleCloudMessaging.
                        MESSAGE_TYPE_DELETED.equals(messageType)) {
                    Log.w(TAG, "Deleted messages on server: " +
                            extras.toString());
                // If it's a regular GCM message, do some work.
                } else if (GoogleCloudMessaging.
                        MESSAGE_TYPE_MESSAGE.equals(messageType)) {
                    Log.w(TAG, "Got MESSAGE_TYPE_MESSAGE");
                    Log.i(TAG, "Received: " + extras.toString());
                }
            }
        } catch (Exception badParse) {
            Log.w(TAG, "Unable to parse received GCM intent: ", badParse);
        }
        return contents;
    }
}
