/*
 * Copyright (c) 2016 CA. All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 *
 */

package com.ca.mas.sample.smc.controller;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ca.mas.core.MobileSso;
import com.ca.mas.core.MobileSsoFactory;
import com.ca.mas.core.conf.ConfigurationManager;
import com.ca.mas.core.smc.CommandConfig;
import com.ca.mas.core.smc.KnoxApp;
import com.ca.mas.core.smc.LogCapture;
import com.ca.mas.core.smc.Manager;

import com.ca.mas.foundation.MAS;
import com.ca.mas.foundation.MASCallback;
import com.ca.mas.foundation.MASUser;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ExampleActivity extends FragmentActivity  {
    private static final String TAG = "SMC Controller";

    private static final int MENU_GROUP_LOGOUT = 66;
    private static final int MENU_ITEM_LOG_OUT = 3;
    private static final int MENU_ITEM_LOG_OUT_CLIENT_ONLY = 1;
    private static final int MENU_ITEM_REMOVE_DEVICE_REGISTRATION = 4;
    private static final int MENU_ITEM_DESTROY_TOKEN_STORE = 2;

    ListView itemList;
    TextView screenOutput;
    ProgressBar progressBar;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);
        
        Log.w(TAG, "========== START, onCreate at " + Manager.getDate(System.currentTimeMillis()) + "==========");
        Manager.getInstance().onResume(this);
        KnoxApp.getInstance();
        
        final Button buttonAttestation = (Button) findViewById(R.id.btnAttestation);
        buttonAttestation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    screenOutput = (TextView)findViewById(R.id.screenOutput);
                    screenOutput.setText("Running Attestation");
                    URI uri = new URI("/smc/attestation/challenge");
                    KnoxApp.getInstance().processKnoxApp(uri, null, null);
                } catch (Exception x) {
                    Log.w(TAG, "Exception initiating attestation: ", x);
                }
            }
        });

        final Button buttonAuditLog = (Button) findViewById(R.id.btnAuditLog);
        buttonAuditLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    screenOutput = (TextView)findViewById(R.id.screenOutput);
                    screenOutput.setText("Posting Audit log");
                    URI uri = new URI("/smc/audit/post");
                    KnoxApp.getInstance().processKnoxApp(uri, null, null);
                } catch (Exception x) {
                    Log.w(TAG, "Exception initiating audit log post: ", x);
                }
            }
        });

        final Button buttonCreateKnoxContainer = (Button) findViewById(R.id.btnCreateKnoxContainer);
        buttonCreateKnoxContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    screenOutput = (TextView)findViewById(R.id.screenOutput);
                    screenOutput.setText("Creating Knox Container");
                    URI uri = new URI("/smc/container/create");
                    KnoxApp.getInstance().processKnoxApp(uri, null, null);
                } catch (Exception x) {
                    Log.w(TAG, "Exception initiating container creation: " + x);
                }
            }
        });
        
        final Button buttonInstallApplication = (Button) findViewById(R.id.btnInstallApplication);
        buttonInstallApplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    screenOutput = (TextView)findViewById(R.id.screenOutput);
                    screenOutput.setText("Installing Application");
                    URI uri = new URI("/smc/app/install");
                    KnoxApp.getInstance().processKnoxApp(uri, null, null);
                } catch (Exception x) {
                    Log.w(TAG, "Exception intiating app install: " + x);
                }
            }
        });

        final Button buttonRemoveApplication = (Button) findViewById(R.id.btnRemoveApplication);
        buttonRemoveApplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    screenOutput = (TextView)findViewById(R.id.screenOutput);
                    screenOutput.setText("Removing Application");
                    URI uri = new URI("/smc/app/remove");
                    KnoxApp.getInstance().processKnoxApp(uri, null, null);
                } catch (Exception x) {
                    Log.w(TAG, "Exception initiating app remove: " + x);
                }
            }
        });

        final Button buttonRemoveKnoxContainer = (Button) findViewById(R.id.btnRemoveKnoxContainer);
        buttonRemoveKnoxContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    screenOutput = (TextView)findViewById(R.id.screenOutput);
                    screenOutput.setText("Removing Knox Container");
                    URI uri = new URI("/smc/container/remove");
                    Log.i(TAG, "6) Remove Container: posting to " + uri);
                    KnoxApp.getInstance().processKnoxApp(uri, null, null);
                } catch (Exception x) {
                    Log.w(TAG, "Exception initiating container removal: " + x);
                }
            }
        });

        final Button buttonPushResponse = (Button) findViewById(R.id.btnPush);
        buttonPushResponse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //mobileSso();
                    screenOutput = (TextView)findViewById(R.id.screenOutput);
                    screenOutput.setText("Retrieve Pending Command");
                    URI uri = new URI("/knox/devicePendingCommand");
                    Log.i(TAG, "Retrieve Pending Command from " + uri);
                    KnoxApp.getInstance().processKnoxApp(uri, null, null);
                } catch (Exception x) {
                    Log.w(TAG, "Exception requesting pending command: " + x);
                }
            }
        });


        //TODO Remove this
        final Button buttonGCMRegistration = (Button) findViewById(R.id.gcmRegistration);
        buttonGCMRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //mobileSso();
                    Map<String, List<String>> actions = new HashMap<String, List<String>>();
                    actions.put(CommandConfig.MSSO_SMC_CMDS_GCM_REGISTER[0], Arrays.asList("159189961643"));
                    actions.put(CommandConfig.MSSO_SMC_CMD_RESPONSE, Arrays.asList("https://" +
                            ConfigurationManager.getInstance().getConnectedGatewayConfigurationProvider().getTokenHost() + ":8443/smc/result"));
                    Manager.getInstance().parseHeaders(actions);
                } catch (Exception x) {
                    Log.w(TAG, "Exception requesting pending command: " + x);
                }
            }
        });


       final Button logOutButton = (Button) findViewById(R.id.btnLogout);
        logOutButton.setOnClickListener(new View.OnClickListener() {
            protected long lastLogout = 0;
            @Override
            public void onClick(View v) {
                screenOutput = (TextView)findViewById(R.id.screenOutput);
                screenOutput.setText("Logout");

                // Store logs to logfile
                Log.w(TAG, "Logout Button");
                LogCapture.getInstance().writeLogToFile();

                //doServerLogout();
                //mobileSso().destroyAllPersistentTokens();
                
                if ((System.currentTimeMillis() - lastLogout) < 2000) {
                    Log.w(TAG, "doServerUnregisterDevice!!!!");
                    doServerLogout();
                    KnoxApp.getInstance().getMobileSso().destroyAllPersistentTokens();
                    doServerUnregisterDevice();
                }
                lastLogout = System.currentTimeMillis();
            }
        });
        registerForContextMenu(logOutButton);
    }
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.add(MENU_GROUP_LOGOUT, MENU_ITEM_LOG_OUT, Menu.NONE, "Log Out");
        menu.add(MENU_GROUP_LOGOUT, MENU_ITEM_LOG_OUT_CLIENT_ONLY, Menu.NONE, "Log Out (client only)");
        menu.add(MENU_GROUP_LOGOUT, MENU_ITEM_REMOVE_DEVICE_REGISTRATION, Menu.NONE, "Unregister Device");
        menu.add(MENU_GROUP_LOGOUT, MENU_ITEM_DESTROY_TOKEN_STORE, Menu.NONE, "Destroy Token Store");
    }





    // Log the user out of all client apps and notify the server to revoke tokens.
    private void doServerLogout() {
        if (MASUser.getCurrentUser() != null) {
            MASUser.getCurrentUser().logout(new MASCallback<Void>() {
                @Override
                public void onSuccess(Void result) {
                    Log.i(TAG, "ExampleActivity logout success, onSuccess ");
                    showMessage("Successful Logout", Toast.LENGTH_SHORT);
                }

                @Override
                public void onError(Throwable e) {
                    Log.i(TAG, "ExampleActivity logout failed, onError " + e);
                    showMessage("Fail Logout", Toast.LENGTH_SHORT);
                }
            });
        }
    }

    // Tell the token server to un-register this device, without affecting the client-side token caches in any way.
    private void doServerUnregisterDevice() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                try {
                    KnoxApp.getInstance().getMobileSso().removeDeviceRegistration();
                    showMessage("Server Registration Removed for This Device", Toast.LENGTH_LONG);
                } catch (Exception e) {
                    String msg = "Server Device Removal Failed: " + e.getMessage();
                    Log.e(TAG, msg, e);
                    showMessage(msg, Toast.LENGTH_LONG);
                }
                return null;
            }
        }.execute((Void) null);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //outState.putInt(STATE_PROGRESS_VISIBILITY, progressBar.getVisibility());
    }

    @Override
    protected void onResume() {
        super.onResume();
        MAS.processPendingRequests();
    }

    public void showMessage(final String message, final int toastLength) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(ExampleActivity.this, message, toastLength).show();
            }
        });
    }


    //@Override
    public static void receivedIntent(Intent intent) {
        Log.i(TAG, "Retrieve Pending Command got intent, action " + intent.getAction());
        try {
            //mobileSso();
            if (Looper.myLooper() == null)
                Looper.prepare();
            MobileSso mobileSso = MobileSsoFactory.getInstance(Manager.getInstance().getMainActivity());
            //screenOutput = (TextView)findViewById(R.id.screenOutput);
            //screenOutput.setText("Retrieve Pending Command " + intent.getExtras());
            URI uri = mobileSso.getURI("/knox/devicePendingCommand");
            Log.i(TAG, "Retrieve Pending Command got intent, retrieving from " + uri + ", intent contents " + intent.getExtras());
            KnoxApp.getInstance().processKnoxApp(uri, null, null);
        } catch (Exception x) {
            Log.w(TAG, "Exception requesting pending command: " + x);
        }
    }


}
