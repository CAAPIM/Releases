//
//  MASUser+FIDO.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import "MASFIDOConstants.h"

#import <MASFoundation/MASUser.h>
#import <MASFoundation/MASConstants.h>



@interface MASUser (FIDO)

/**
 *  Register a user via FIDO UAF request with user's Biometric credentials.
 *
 *  @param userName The userName of the user.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.
 */
+ (void)registerWithFIDOUserName:(NSString *_Nonnull)userName
                      completion:(MASResponseInfoErrorBlock _Nonnull)completion;



/**
 *  Authenticate a user via FIDO UAF request with pre-registered Biometric credentials.
 *
 *  This will create an [MAUser currentUser] upon a successful result.
 *
 *  @param userName The userName of the user.
 *  @param completion The MASCompletionErrorBlock block that receives the results.  On a successful completion, the user
 *  available via [MASUser currentUser] has been updated with the new information.
 */
+ (void)loginWithFIDOUserName:(NSString *_Nonnull)userName
                   completion:(MASCompletionErrorBlock _Nonnull)completion;



/**
 *  Confirm a critical transaction via FIDO UAF request with pre-registered Biometric credentials.
 *
 *  This will create an [MAUser currentUser] upon a successful result.
 *
 *  @param userName The userName of the user.
 *  @param message The message about the critical transaction that needs the confirmation of the user.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.  On a successful completion, the user
 *  available via [MASUser currentUser] has been updated with the new information.
 */
+ (void)confirmTransactionWithFIDOUserName:(NSString *_Nonnull)userName
                                   message:(NSString *_Nonnull)message
                                completion:(MASResponseInfoErrorBlock _Nonnull)completion;



/**
 *  De-Register a user's biometrics via FIDO UAF request with given deregistration options.
 *
 *  @param userName The userName of the user.
 *  @param option A MASFIDODeregistrationOptions to deregister all the biometric registered modalities or
 *          deregister biometric modalities by AAID.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *          receive the JSON response object or an NSError object if there is a failure.  On a successful completion, the
 *          user's Biometric credentials are de-registered.
 */
+ (void)deregisterWithFIDOUserName:(NSString *_Nonnull)userName
                           options:(MASFIDODeregistrationOptions)option
                        completion:(MASResponseInfoErrorBlock _Nonnull)completion;



///--------------------------------------
/// @name Deprecated
///--------------------------------------

# pragma mark - Deprecated

/**
 *  De-Register a user via FIDO UAF request with all of the pre-registered Biometric credentials.
 *
 *  @param userName The userName of the user.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.  On a successful completion, the
 *  user's
 *  Biometric credentials are de-registered.
 */
+ (void)deregisterWithFIDOUserName:(NSString *_Nonnull)userName
                        completion:(MASResponseInfoErrorBlock _Nonnull)completion DEPRECATED_MSG_ATTRIBUTE("[MASUser deregisterWithFIDOUserName:completion:] is deprecated.  Use [MASUser deregisterWithFIDOUserName:options:completion:] instead.");

/**
 *  De-Register a user via FIDO UAF request with selected pre-registered Biometric credentials.
 *
 *  @param userName The userName of the user.
 *  @param completion An MASResponseInfoErrorBlock (NSDictionary *responseInfo, NSError *error) that will
 *      receive the JSON response object or an NSError object if there is a failure.  On a successful completion, the
 *  user's selected
 *  Biometric credentials are de-registered.
 */
+ (void)deregisterAAIDsForFIDOUserName:(NSString *_Nonnull)userName
                            completion:(MASResponseInfoErrorBlock _Nonnull)completion DEPRECATED_MSG_ATTRIBUTE("[MASUser deregisterAAIDsForFIDOUserName:completion:] is deprecated.  Use [MASUser deregisterWithFIDOUserName:options:completion:] instead.");

@end
