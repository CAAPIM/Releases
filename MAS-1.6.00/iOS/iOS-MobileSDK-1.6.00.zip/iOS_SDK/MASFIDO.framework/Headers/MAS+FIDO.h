//
//  MAS+FIDO.h
//  MASFIDO
//
//  Copyright (c) 2017 CA. All rights reserved.
//
//  This software may be modified and distributed under the terms
//  of the MIT license. See the LICENSE file for details.
//

#import "MASFIDOConstants.h"



@interface MAS (FIDO)

/**
 Return the currently configured FIDO Provider for MASFIDO
 
 @return MASFIDOProviderType configured for MASFIDO
 */
+ (MASFIDOProviderType)MASFIDOProviderType;



/**
 *  Set a biometric registration modalities selection block to handle the case where SDK requires biometric registration modalities.
 *
 *  When a biometric registration is required, SDK will invoke this block
 *  to obtain biometricModalities list to proceed with registration process.
 *
 *  @param biometricRegistrationModalitiesSelector MASBiometricRegistrationModalitiesSelectionBlock that contains callback block
 *  to be invoked with user selected biometricModalities list.
 */
+ (void)setBiometricRegistrationModalitiesSelectionBlock:(MASBiometricRegistrationModalitiesSelectionBlock)biometricRegistrationModalitiesSelector;



/**
 *  Set a biometric deregistration modalities selection block to handle the case where SDK requires biometric deregistration
 *  modalities.
 *
 *  When a biometric deregistration is required, SDK will invoke this block
 *  to obtain biometricModalities list to proceed with deregistration process.
 *
 *  @param biometricDeregistrationModalitiesSelector MASBiometricDeregistrationModalitiesSelectionBlock that contains callback block
 *  to be invoked with user selected biometricModalities list.
 */
+ (void)setBiometricDeregistrationModalitiesSelectionBlock:(MASBiometricDeregistrationModalitiesSelectionBlock)biometricDeregistrationModalitiesSelector;

@end
