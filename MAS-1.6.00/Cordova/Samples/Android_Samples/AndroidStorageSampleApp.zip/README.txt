1. Copy your msso_config.json file inside platforms/android/assets folder
2. Copy the MAS libraries inside platforms/android/libs folder. Name the libraries as mentioned in the build.gradle file.