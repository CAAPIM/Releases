var rootUser;
// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

.run(function($ionicPlatform, $rootScope) {
    $ionicPlatform.ready(function() {
        if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);

        }
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }
        /*
                var populateFriendsList = function() {

                    $ionicPlatform.friends = [{
                        "userName": "Loading"
                    }];
                    var filterRequest = {};
                    var userAttribute = "userName";
                    var operator = "co";
                    var attributeValue = "";
                    var filterStr = userAttribute + "::" + operator + "::" + attributeValue;
                    filterRequest.filter = [filterStr];
                    filterRequest.sortOrder = "ascending";
                    filterRequest.sortAttribute = "userName";
                    filterRequest.pagination = [1, 10];
                    MASPluginUser.getUsersByFilter(function(result) {
                        console.log(result);
                        $ionicPlatform.friends = result;
                        $ionicPlatform.$apply;

                    }, function(error) {
                        console.log(error);
                    }, filterRequest);
                }
                var populateCurrentUser = function() {
                    MASPluginUser.currentUser(function(result) {
                            $rootScope.user = result;
                            $ionicPlatform.user = result;
                            $ionicPlatform.emailAddress = result.emailAddresses;
                            $ionicPlatform.$apply;
                            populateFriendsList();
                            result.getThumbnailImage(function(result) {
                                    $ionicPlatform.thumbnail = result;
                                    $ionicPlatform.$apply;
                                },
                                function(error) {
                                    console.log(error);
                                    alert("getThumbnailImage failure");

                                });

                        },
                        function(error) {
                            console.log(error);


                        }, true);
                };
        */
        MASPluginUtils.setPopUpStyle("position: fixed; top: 50%; left:50%; transform: translate(-50%, -50%); height: 100%!;width: 100%!; overflow: auto");
        console.log(MASPluginUtils.getPopUpStyle());


        var MAS = new MASPlugin.MAS();
        /*
                MAS.initialize(function(result) {
                    console.log("MAS init success");
                    MAS.start(function(result) {
                        console.log("MAS Start success");

                        MAS.useNativeMASUI(function(result) {
                            console.log(result);
                        }, function(error) {
                            console.log(error);
                        });
                        MAS.getFromPath(function(result) {
                                console.log("MAS getFromPath success");
                                populateCurrentUser();
                                //Subscribe to messages here
                                MASPluginUser.currentUser(function(MASUser) {
                                        rootUser = MASUser;
                                        $rootScope.user = MASUser;
                                        /*MASConnectaPlugin.MASUser.startListeningToMyMessages(function(result) {
                                            console.log("MASPluginUser startListeningToMyMessages success");
                                        }, function(error) {
                                            console.log(error);
                                            console.log("MASPluginUser startListeningToMyMessages error" + error.errorMessage);
                                            alert("Listen to messages failure");
                                        });* /
                                    },
                                    function(error) {
                                        console.log(error);
                                        console.log("MASPluginUser currentUser error" + error.errorMessage);
                                        alert("Listen to messages failure. Fetch current user failure");
                                    }, true);

                            },
                            function(error) {
                                console.log(error);
                                console.log("MAS getFromPath error" + error.errorMessage);
                                //alert("/protected/resource/products failure");
                                alert(error.errorMessage);

                            }, "/protected/resource/products", null, null, 0, 0);


                    }, function() {
                        alert("MAS Start failure");
                    });
                }, function(error) {
                    console.log(error);
                    alert("Initialization failure");

                });
        */

    });
})

.config(function($stateProvider, $urlRouterProvider) {

    // Ionic uses AngularUI Router which uses the concept of states
    // Learn more here: https://github.com/angular-ui/ui-router
    // Set up the various states which the app can be in.
    // Each state's controller can be found in controllers.js
    $stateProvider

    // setup an abstract state for the tabs directive
        .state('tab', {
        url: '/tab',
        abstract: true,
        templateUrl: 'templates/tabs.html'
    })

    // Each tab has its own nav history stack:

    .state('tab.dash', {
        url: '/dash',
        views: {
            'tab-dash': {
                templateUrl: 'templates/tab-dash.html',
                controller: 'DashCtrl'
            }
        }
    })

    .state('tab.chats', {
            url: '/chats',
            views: {
                'tab-chats': {
                    templateUrl: 'templates/tab-friends.html',
                    controller: 'ChatsCtrl'
                }
            }
        })
        .state('tab.chat-detail', {
            url: '/chats/:chatId',
            views: {
                'tab-chats': {
                    templateUrl: 'templates/chat-detail.html',
                    controller: 'ChatDetailCtrl'
                }
            }
        })
        .state('tab.group-detail', {
            url: '/groups/:groupId',
            views: {
                'tab-dash': {
                    templateUrl: 'templates/group-detail.html',
                    controller: 'GroupDetailCtrl'
                }
            }
        })

    .state('tab.account', {
        url: '/account',
        views: {
            'tab-account': {
                templateUrl: 'templates/tab-account.html',
                controller: 'AccountCtrl'
            }
        }
    });

    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/tab/account');
    //$urlRouterProvider.otherwise('/tab/chats/abc');
});