angular.module('starter.controllers', [])

//User Group List 
.controller('DashCtrl', function($scope, $ionicPlatform, $rootScope) {
    $scope.groups = [];

    //Array list of group names
    //$scope.groupNames = [];


    /*$scope.accessProtectedResource = function() {
        var MAS = new MASPlugin.MAS();
        MAS.getFromPath(function(groupObject) {

                console.log("MAS getFromPath success");
                $scope.message = "";
                $scope.$apply();
                MASPluginUser.currentUser(function(MASUser) {
                        rootUser = MASUser;
                        $rootScope.user = MASUser;

                    },
                    function(error) {
                        console.log(error);
                        console.log("MASPluginUser currentUser error" + error.errorMessage);
                        alert("Listen to messages failure. Fetch current user failure");
                    });
            },
            function(error) {
                console.log(error);
                console.log("MAS getFromPath error" + error.errorMessage);
                alert("/protected/resource/products failure");
                $scope.messageColor = "red";
                $scope.message = "Getting groups failed";
                $scope.$apply();
            }, "/protected/resource/products", null, null, 0, 0);
    };
*/


    $scope.getAndAddGroupToList = function(groupValue) {

        var MASGroup = new MASIdentityManagementPlugin.MASGroup();
        MASGroup.getGroupByObjectId(function(groupObject) {
            console.log(groupObject);

            //if ($scope.groupNames.indexOf(groupObject.displayName) == -1) {
            $scope.groups.push(groupObject);
            //$scope.groupNames.push(groupObject.displayName);

            //start listening to group topic 
            //Plugin does not provide this support. 
            //
            //}
            $scope.message = "";
            $ionicPlatform.userGroups = $scope.groups;
            $scope.$apply();
        }, function(error) {
            console.log(error);
            $scope.messageColor = "red";
            $scope.message = "Getting groups failed";
            $scope.$apply();
        }, groupValue);
    };
    $scope.populateGroups = function(groups) {
        console.log(groups);

        for (var i = 0; i < groups.length; i++) {
            var groupValue = groups[i].value;
            $scope.getAndAddGroupToList(groupValue);
        }


    };

    $scope.populateCurrentUserGroups = function() {
        MASPluginUser.currentUser(function(groupObject) {
                $scope.user = groupObject;
                $scope.groups = [];
                $scope.populateGroups(groupObject.groups);
            },
            function(error) {
                console.log(error);

                //$scope.accessProtectedResource();
                $scope.messageColor = "red";
                $scope.message = "Getting groups failed";
                $scope.$apply();
            });
    };
    $scope.$on('$ionicView.enter', function() {
        // code to run each time view is entered
        console.log("Calling populateCurrentUserGroups");
        $scope.populateCurrentUserGroups();
    });
})

//Friends tab
.controller('ChatsCtrl', function($scope, Chats, $ionicPlatform, $ionicLoading) {
    // With the new view caching in Ionic, Controllers are only called
    // when they are recreated or on app start, instead of every page change.
    // To listen for when this page is active (for example, to refresh data),
    // listen for the $ionicView.enter event:
    //
    //$scope.$on('$ionicView.enter', function(e) {
    //});

    $scope.chats; // = Chats.all();
    $scope.friends; // = $ionicPlatform.friends;

    $scope.getFriendsList = function() {

        $ionicLoading.show({
            content: 'Loading',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        var filterRequest = {};
        var userAttribute = "userName";
        var operator = "co";
        //var attributeValue = "mujeeb";
        var attributeValue = "";
        var filterStr = userAttribute + "::" + operator + "::" + attributeValue;
        filterRequest.filter = [filterStr];
        filterRequest.sortOrder = "ascending";
        filterRequest.sortAttribute = "userName";
        filterRequest.pagination = [1, 100];
        MASPluginUser.getUsersByFilter(function(groupObject) {
            console.log(groupObject);
            $scope.message = "";
            $scope.friends = groupObject;
            $ionicPlatform.friends = $scope.friends;
            $scope.$apply();
            $ionicLoading.hide();
        }, function(error) {
            console.log(error);
            $scope.message = "Failed to get friends list." + error.errorMessage;
            $scope.messageColor = "red";
            $ionicLoading.hide();
            $scope.$apply();
        }, filterRequest);

    };
    $scope.onRefreshFriends = function() {
        $scope.getFriendsList();
    };
    $scope.onRefreshFriends();

})

.controller('ChatDetailCtrl', function($scope, $stateParams, $ionicPlatform, $location, $anchorScroll, $rootScope) {



    var frens = $ionicPlatform.friends;

    $scope.friend;
    $scope.phone;
    $scope.emailAddress;
    $scope.messages = [];
    $scope.user = $rootScope.user;


    /*for (var j = 0; j < 5; j++) {
      //$scope.messages.push('{ "Version": "1.0", "SenderId": "Kiran", "SenderType": "USER", "DisplayName": "Kiran", "SentTime": 148516903836' + i + ', "ContentType": "text/plain", "ContentEncoding": "BASE64", "Payload": "SGVsbG8=", "Topic": "/2.0/client/users/robert/custom/robert" } ');
      var str = '{ "Version": "1.0", "SenderId": "Kiran", "SenderType": "USER", "DisplayName": "Kiran", "SentTime": 148516903836' + j + ', "ContentType": "text/plain", "ContentEncoding": "BASE64", "Payload": "SGVsbG8=", "Topic": "/2.0/client/users/robert/custom/robert" } ';

      var json = JSON.parse(str);
      json.text = atob(json.Payload);
      json.SenderId = json.SenderId;
      json.SentTime = json.SentTime;
      $scope.messages.push(json);

    }*/
    for (var i = 0; i < frens.length; i++) {
        if (frens[i].userName === $stateParams.chatId) {
            $scope.friend = frens[i];
            var groupObject = frens[i];
            if (groupObject.phoneNumbers != null && groupObject.phoneNumbers.length > 0) {
                var item = groupObject.phoneNumbers[0];
                $scope.phone = item.work;
            } else {
                $scope.phone = "Not available";
            }

            if (groupObject.emailAddresses != null && groupObject.emailAddresses.length > 0) {
                var item2 = groupObject.emailAddresses[0];
                $scope.emailAddress = item2.work;
            } else {
                $scope.emailAddress = "Not available";
            }
            $scope.address = "Not available";
            break;
        }
    }

    var messagesToString = function() {
        var myArray = $scope.messages;
        var arrayLength = myArray.length;
        var returnValue = "";
        for (var i = 0; i < arrayLength; i++) {
            returnValue += myArray[i].SenderId + "##" + myArray[i].SentTime + "##" + myArray[i].text + "||";
        }
        console.log("messagesToString result :" + returnValue);
        return returnValue;
    };


    var reconstructMessage = function(str) {
        var msg = str.split("##");
        var newMessage = {
            SenderId: "John",
            SentTime: "Doe",
            text: "blue"
        };
        newMessage.SenderId = msg[0];
        newMessage.SentTime = msg[1];
        newMessage.text = msg[2];
        if (newMessage.SenderId === $rootScope.user.userName) {
            newMessage.isSent = "true";
        } else {
            newMessage.isSent = null;
        }
        return newMessage;
    };

    var populateMessagesInScope = function(msgString) {
        $scope.messages = [];
        var msgArray = msgString.split("||");
        for (var a = 0; a < msgArray.length; a++) {
            if (msgArray[a] === null || "" === msgArray[a]) {
                break;
            }
            var newMessage = reconstructMessage(msgArray[a]);
            $scope.messages.push(newMessage);
        }

        $scope.$apply();
    };


    $scope.onUploadMessagesBtnClick = function(key, value) {
        $scope.backupMessages(key, value, true);
    };
    $scope.backupMessages = function(key, value, showConfirmationMessage) {
        if (!key) {
            key = $scope.friend.userName;
            value = messagesToString();
        }
        var MASSecureCloudStorage = new MASStoragePlugin.MASSecureCloudStorage();
        console.log("upload to cloud. Key :" + key + " Value: " + value)
        MASSecureCloudStorage.save(function(result) {
                console.log("messages backup successful");
                console.log(result);
                if (showConfirmationMessage)
                    alert("Messages uploaded to cloud");
            },
            function(error) {
                console.log("messages backup failure");
                console.log(error);
                if (showConfirmationMessage)
                    alert("Messages upload to cloud failed");
            }, "text/plain", key, value, 0);
    };

    $scope.getMessageFromCloud = function(username, populateMessagesUI) {
        if (!username) {
            username = $scope.friend.userName;
        }
        var MASSecureCloudStorage = new MASStoragePlugin.MASSecureCloudStorage();
        MASSecureCloudStorage.findByUsingKeyAndMode(function(result) {

            console.log("Got messages from cloud:" + atob(result.value));
            if (populateMessagesUI)
                populateMessagesInScope(atob(result.value));
            else
                return atob(result.value)
        }, function(error) {
            console.log(error);
        }, username, 0);

    };

    $scope.sendMessage = function(message) {
        console.log("Sending message");
        console.log(message + "   " + $scope.friend);

        /*MASConnectaPlugin.MASUser.sendMessageToUser(function(result) {
                            
                            thisElement.removeClass("succes").removeClass("failure").addClass("success");
                            displayResult(thisElement, result);
                        },
                        function(error) {
                                        
                            thisElement.removeClass("succes").removeClass("failure").addClass("failure");
                            displayError(thisElement, error);
                        }, 
                        message, userObjectId);
        */


        MASPluginUser.currentUser(function(MASUser) {
                $rootScope.user = MASUser;
                MASConnectaPlugin.MASUser.sendMessageToUser(function(result) {
                        $scope.message = '';
                        console.log("Message sent to user");
                        console.log(result);
                        var newMessage = {
                            SenderId: "John",
                            SentTime: "Doe",
                            text: "blue"
                        };
                        newMessage.SenderId = $rootScope.user.userName;
                        var d = new Date();
                        var timeInMillis = d.getTime();
                        newMessage.SentTime = timeInMillis;
                        newMessage.text = message; //btoa(message);
                        newMessage.isSent = "true";
                        $scope.messages.push(newMessage);

                        $scope.$apply();
                        $location.hash('bottom');
                        $anchorScroll();
                    },
                    function(error) {
                        console.log("Message sending failed");
                        console.log(error);
                        alert("Message sending failed because of unknown reasons");
                    }, btoa(message), $scope.friend.userName);
            },
            function(error) {
                console.log("Get current user failed");
                console.log(error);
            });

    };



    var messageToString = function(message) {
        var str = "";
        str += message.SenderId;
        str += "##";
        str += message.SentTime;
        str += "##";
        str += message.text;
        str += "||";
        return str;
    };
    $scope.getMessageFromCloud($scope.friend.userName, true);
    console.log($rootScope.counter++);
    MASConnectaPlugin.MASRegisterListener(function(success) {
            if (null != success.Payload) {
                success.SenderId = success.DisplayName;
                var message = {};
                message.SenderId = success.SenderId;
                var payload = (success.Payload != null ? success.Payload : success.payload);
                message.text = atob(payload);
                message.topic = success.Topic;
                message.SentTime = success.SentTime;

                console.log("Got Message at ChatDetailsCtrl  From : " + success.SenderId + " Text : " + message.text);
                if (success.SenderId == $scope.friend.userName) {
                    $scope.messages.push(message);
                    $scope.backupMessages($scope.friend.userName, messagesToString());
                    $scope.$apply();

                    $location.hash('bottom');
                    $anchorScroll();
                } else {

                    //Get senderId from message
                    //Get from cloud using senderId
                    //append new message to message list
                    //upload to cloud
                    var stringFromCloud = $scope.getMessageFromCloud(success.SenderId);
                    var msgStr = messageToString(stringFromCloud);
                    var stringToCloud = stringFromCloud + msgStr;
                    $scope.backupMessages(success.SenderId, stringToCloud);
                }
            }
        },
        function(error) {
            console.log("Listener registration failed!!!:" + JSON.stringify(error));
        });
    return null;

})

.controller('GroupDetailCtrl', function($scope, $stateParams, $ionicPlatform) {

    var groups = $ionicPlatform.userGroups;

    $scope.members;
    // = Chats.get($stateParams.chatId);
    for (var i = 0; i < groups.length; i++) {
        if (groups[i].id === $stateParams.groupId) {
            $scope.members = groups[i].members;
            $scope.group = groups[i];
            return;
        }
    }
    return null;

})

.controller('AccountCtrl', function($scope, $ionicLoading, $ionicPlatform, $rootScope, $ionicHistory, $window, Chats) {
    $scope.chat = Chats;
    $scope.message;
    $scope.messageColor;
    //$scope.showLoginButton = false;
    //$scope.showLogoutButton = true;
    $scope.showLoginButton = true;
    $scope.showLogoutButton = false;
    $scope.phone;
    $scope.emailAddress;
    $scope.address;

    $scope.populateCurrentUser = function() {

        MASPluginUser.currentUser(function(groupObject) {
                console.log(groupObject);
                $scope.user = groupObject;
                $rootScope.user = groupObject;
                if (groupObject.phoneNumbers != null && groupObject.phoneNumbers.length > 0) {
                    var item = groupObject.phoneNumbers[0];
                    $scope.phone = item.work;
                } else {
                    $scope.phone = "Not available";
                }

                if (groupObject.emailAddresses != null && groupObject.emailAddresses.length > 0) {
                    var item = groupObject.emailAddresses[0];
                    $scope.emailAddress = item.work;
                } else {
                    $scope.emailAddress = "Not available";
                }
                $scope.address = "Not available";


                $scope.$apply();
                //populateFriendsList();
                groupObject.getThumbnailImage(function(groupObject) {
                        //console.log(groupObject);
                        $scope.message = "";
                        groupObject = groupObject.replace("\\", "");
                        $scope.thumbnail = groupObject;
                        $scope.$apply();
                    },
                    function(error) {
                        console.log(error);
                        //alert("getThumbnailImage failure");
                        $scope.message = "getThumbnailImage failure";
                        $scope.messageColor = "red";
                        $scope.$apply();
                    });
                //$scope.populateGroups(groupObject.groups);

            },
            function(error) {
                console.log(error);
                $scope.message = "Unable to fetch user details";
                $scope.messageColor = "red";
                $scope.$apply();
                $scope.accessProtectedResource();
            }, true);
    }


    $scope.logout = function() {

        MASPluginUser.currentUser(function(currentUser) {
                currentUser.logout(function(groupObject) {
                        var MASDevice = new MASPlugin.MASDevice();
                        MASDevice.deregister(function(groupObject) {
                            $rootScope.user = null;
                            $scope.messageColor = "green";
                            $scope.message = "Logout successful";
                            $scope.showLoginButton = true;
                            $scope.showLogoutButton = false;
                            $scope.phone = "";
                            $scope.emailAddress = "";
                            $scope.user = null;
                            $scope.thumbnail = "";
                            $scope.address = "";
                            $window.localStorage.clear();
                            $ionicHistory.clearCache();
                            $ionicHistory.clearHistory();
                            $scope.$apply();
                        }, function(error) {
                            console.log(error);
                            $scope.messageColor = "red";
                            $scope.message = "Device deregister failure";
                            $scope.$apply();
                        });
                    },
                    function(error) {
                        console.log(error);
                        $scope.messageColor = "red";
                        $scope.message = "User logout failure";
                        $scope.$apply();
                    });
            },
            function(error) {
                console.log(error);
                $scope.message = "Unable to fetch user details";
                $scope.messageColor = "red";
                //$scope.messageColor = "green";
                $scope.message = "Logout failure";
                //$scope.showLoginButton = true;
                $scope.showLogoutButton = true;
                $scope.phone = "";
                $scope.emailAddress = "";
                $scope.address = "";
                $scope.$apply();
                $scope.$apply();
            });
    };

    $scope.accessProtectedResource = function() {
        console.log("Invoking accessProtectedResource from Account Controller");
        var MAS = new MASPlugin.MAS();
        MAS.getFromPath(function(groupObject) {
                console.log("MAS getFromPath success");
                $scope.showLoginButton = false;
                $scope.showLogoutButton = true;
                $scope.messageColor = "green";
                $scope.message = "Login successful";

                MASPluginUser.currentUser(function(MASUser) {
                        $rootScope.user = MASUser;
                        $scope.populateCurrentUser();
                        MASConnectaPlugin.MASUser.startListeningToMyMessages(function(result) {
                            console.log("MASPluginUser startListeningToMyMessages success");
                        }, function(error) {
                            console.log(error);
                            console.log("MASPluginUser startListeningToMyMessages error" + error.errorMessage);
                            alert("Listen to messages failure");
                        });
                    },
                    function(error) {
                        console.log(error);
                        console.log("MASPluginUser currentUser error" + error.errorMessage);

                    }, true);

                //Setup message receiver
                MASConnectaPlugin.MASRegisterListener(function(success) {

                    if (null != success.Payload) {
                        var message = {};
                        message.sender = success.SenderId;
                        var payload = (success.Payload != null ? success.Payload : success.payload);
                        message.payload = atob(payload);
                        message.topic = success.Topic;
                        //Parse message here
                        //  alert(JSON.stringify(message) + " 2");
                        console.log("Got Message at AccountCtrl From : " + success.SenderId + " Text : " + payload);
                    }
                }, function(error) {
                    console.log("Listener registration failed!!!:" + JSON.stringify(error));
                });



                $scope.$apply();
            },
            function(error) {
                console.log(error);
                console.log("MAS getFromPath error" + error.errorMessage);
                $scope.messageColor = "red";
                $scope.message = "Unable to fetch user details";
                $scope.$apply();

            }, "/protected/resource/products", null, null, 0, 0);
    };

    angular.element(document).ready(function() {
        console.log('page loading completed');
        console.log("On routeChangeSuccess invoking accessProtectedResource from Account Controller");
        var MAS = new MASPlugin.MAS();
        MAS.initialize(function(result) {
            console.log("MAS init success");
            MAS.start(function(result) {
                console.log("MAS Start success");

                /*MAS.useNativeMASUI(function(result) {
                    console.log(result);
                }, function(error) {
                    console.log(error);
                });*/

                $scope.accessProtectedResource();


            }, function() {
                alert("MAS Start failure");
            });
        }, function(error) {
            console.log(error);
            alert("Initialization failure");

        });

    });
    /*$scope.$on('$viewContentLoaded', function() {
        // do something
});*/

});