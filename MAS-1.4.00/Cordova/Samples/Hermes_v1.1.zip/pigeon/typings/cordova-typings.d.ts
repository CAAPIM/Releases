
/// <reference path="..\.vscode\typings\cordova\plugins\Splashscreen.d.ts"/>