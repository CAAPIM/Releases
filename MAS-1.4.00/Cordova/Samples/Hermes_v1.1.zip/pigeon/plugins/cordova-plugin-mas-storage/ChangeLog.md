# Version 1.4

### Bug fixes
- Improved Error handling.

### New features

- Refactoring the code - Modified sample index.html file to be in sync with latest Foundation APIs.Removed junk code. Removed deprecated class reference from plugin.xml  [US298706]

### Deprecated classes

- None.

# Version 1.3.00

### Bug fixes

- .

### New features

- .

### Deprecated methods

- .


 [mag]: https://docops.ca.com/mag
 [mas.ca.com]: http://mas.ca.com/
 [docs]: http://mas.ca.com/docs/
 [blog]: http://mas.ca.com/blog/

 [releases]: ../../releases
 [contributing]: /CONTRIBUTING.md
 [license-link]: /LICENSE
