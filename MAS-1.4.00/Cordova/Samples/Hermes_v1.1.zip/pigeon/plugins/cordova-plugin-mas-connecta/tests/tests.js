/**
 * Copyright (c) 2016 CA, Inc. All rights reserved.
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file for details.
 *
 */

/**
 *Below are the manual tests for the MASPlugin.
 *
 *Note: Once the start is successful, please make sure that device is deregistered and the app is clean and relaunched before running another
 * test. As we found some issues related to time out to numerous async calls.
 */

exports.defineManualTests = function(contentEl, createActionButton) {
    
};
