# UserFinder
This sample app uses the MASFoundation and MASIdentityManagement frameworks of the MAS SDK.

It has only one screen with a single input text field where users can find other users from the LDAP.
