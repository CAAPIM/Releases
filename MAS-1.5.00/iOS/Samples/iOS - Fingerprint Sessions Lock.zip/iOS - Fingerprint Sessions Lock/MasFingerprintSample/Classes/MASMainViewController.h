//
//  MASMainViewController.h
//  MasFingerprintSample
//
//  Created by Woods, Brendan on 2016-11-03.
//  Copyright © 2016 Ca Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


/**
 * The main view controller for this sample app
 */
@interface MASMainViewController : UIViewController

@end
